package com.hwush.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

private val tabNames = listOf("Arrange", "Piano roll", "Mixer", "Play")

@Composable
fun StudioScreen() {
    val ctx = LocalContext.current
    val file = remember { File(ctx.filesDir, "project.json") }
    val project = remember { ProjectState().also { it.load(file) } }
    val live = remember { LiveState() }
    var tab by remember { mutableIntStateOf(0) }

    // read the engine's clock and meters about thirty times a second
    LaunchedEffect(Unit) {
        while (true) {
            live.beats = NativeEngine.nativePositionBeats()
            live.playing = NativeEngine.nativeIsPlaying()
            live.masterPeak = NativeEngine.nativeMasterPeak()
            live.load = NativeEngine.nativeDspLoad()
            live.latency = NativeEngine.nativeLatencyMs()
            live.xruns = NativeEngine.nativeXruns()
            delay(33)
        }
    }

    // autosave shortly after the last change
    LaunchedEffect(project.version) {
        if (project.version > 0) {
            delay(800)
            withContext(Dispatchers.IO) { project.save(file) }
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        TransportBar(project, live)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> ArrangeScreen(project, live, onOpenRoll = { tab = 1 })
                1 -> PianoRollScreen(project, live)
                2 -> MixerScreen(project, live)
                else -> PlayScreen(project)
            }
        }
        NavigationBar(containerColor = Panel) {
            tabNames.forEachIndexed { i, name ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i },
                    icon = { Text(tabGlyph(i), fontSize = 18.sp) },
                    label = { Text(name, fontSize = 11.sp) },
                )
            }
        }
    }
}

private fun tabGlyph(i: Int): String = when (i) {
    0 -> "▤"
    1 -> "♪"
    2 -> "☰"
    else -> "♫"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TransportBar(project: ProjectState, live: LiveState) {
    var menuOpen by remember { mutableStateOf(false) }
    var tempoDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Hwush Studio", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "DSP ${(live.load * 100).toInt()}%  ·  " +
                        (if (live.latency > 0f) "${live.latency.toInt()} ms" else "- ms") +
                        "  ·  drops ${live.xruns}",
                    fontSize = 11.sp, color = Soft,
                )
            }
            Box {
                OutlinedButton(onClick = { menuOpen = true }) { Text("Project") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("New project") }, onClick = { menuOpen = false; NativeEngine.nativePause(); project.newProject() })
                    DropdownMenuItem(text = { Text("Load demo song") }, onClick = { menuOpen = false; NativeEngine.nativePause(); project.loadDemo() })
                    DropdownMenuItem(text = { Text("Undo") }, enabled = project.canUndo, onClick = { menuOpen = false; project.undo() })
                    DropdownMenuItem(text = { Text("Redo") }, enabled = project.canRedo, onClick = { menuOpen = false; project.redo() })
                }
            }
        }
        if (!AppState.audioOk) {
            Text("Could not open the audio output. Close other audio apps and reopen this one.", color = Color(0xFFFF8B8B), fontSize = 12.sp)
        }
        FlowRow(
            Modifier.fillMaxWidth().padding(top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Button(onClick = { if (live.playing) NativeEngine.nativePause() else NativeEngine.nativePlay() }) {
                Text(if (live.playing) "Pause" else "Play")
            }
            OutlinedButton(onClick = { NativeEngine.nativePause(); NativeEngine.nativeSeekBeats(0.0) }) { Text("Stop") }
            Box(Modifier.padding(top = 10.dp)) {
                Text(positionText(live.beats), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            }
            OutlinedButton(onClick = { tempoDialog = true }) { Text("${project.bpm.toInt()} BPM") }
            FilterChip(selected = project.loop, onClick = { project.toggleLoop() }, label = { Text("Loop") })
            FilterChip(selected = project.metronome, onClick = { project.toggleMetronome() }, label = { Text("Click") })
            OutlinedButton(onClick = { project.undo() }, enabled = project.canUndo) { Text("Undo") }
            OutlinedButton(onClick = { project.redo() }, enabled = project.canRedo) { Text("Redo") }
        }
    }

    if (tempoDialog) {
        var temp by remember { mutableStateOf(project.bpm) }
        AlertDialog(
            onDismissRequest = { tempoDialog = false },
            title = { Text("Tempo: ${temp.toInt()} BPM") },
            text = {
                Slider(value = temp, onValueChange = { temp = Math.round(it).toFloat() }, valueRange = 40f..220f)
            },
            confirmButton = { TextButton(onClick = { project.changeBpm(temp); tempoDialog = false }) { Text("Set") } },
            dismissButton = { TextButton(onClick = { tempoDialog = false }) { Text("Cancel") } },
        )
    }
}

private fun positionText(beats: Double): String {
    val bar = (beats / 4).toInt() + 1
    val beat = (beats % 4).toInt() + 1
    return "Bar $bar.$beat"
}
