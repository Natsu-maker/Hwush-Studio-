package com.hwush.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object AppState {
    var audioOk by mutableStateOf(true)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { StudioTheme { StudioScreen() } }
    }

    override fun onStart() {
        super.onStart()
        AppState.audioOk = NativeEngine.nativeStart()
    }

    override fun onStop() {
        NativeEngine.nativeStop()
        super.onStop()
    }
}
