package com.hwush.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val CellW = 30.dp
private val CellH = 26.dp
private val KeysW = 64.dp
private const val TOP_PITCH = 84   // C6
private const val LOW_PITCH = 36   // C2

private val drumRows = listOf(
    49 to "Crash", 46 to "Open hat", 42 to "Hat", 39 to "Clap",
    38 to "Snare", 37 to "Rim", 45 to "Tom", 36 to "Kick",
)

private val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private fun pitchName(p: Int) = noteNames[p % 12] + (p / 12 - 1)
private fun isBlack(p: Int): Boolean {
    val m = p % 12
    return m == 1 || m == 3 || m == 6 || m == 8 || m == 10
}

private val lengthChoices = listOf("1/16" to STEP, "1/8" to STEP * 2, "1/4" to STEP * 4, "1/2" to STEP * 8, "Bar" to STEP * 16)

@Composable
fun PianoRollScreen(project: ProjectState, live: LiveState) {
    val ti = project.selected.coerceIn(0, (project.tracks.size - 1).coerceAtLeast(0))
    val track = project.tracks.getOrNull(ti)
    if (track == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No track", color = Soft) }
        return
    }
    val drums = track.kind == 1
    val color = trackColor(track.colorIdx)
    val rows: List<Int> = if (drums) drumRows.map { it.first } else (TOP_PITCH downTo LOW_PITCH).toList()
    val steps = project.bars * 16
    val gridW = CellW * steps
    val gridH = CellH * rows.size
    var lenIdx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val vScroll = rememberScrollState(if (drums) 0 else with(density) { (CellH * 10).roundToPx() })
    val hScroll = rememberScrollState()
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(track.name, color = color, fontSize = 15.sp)
            if (!drums) {
                for ((i, c) in lengthChoices.withIndex()) {
                    FilterChip(selected = lenIdx == i, onClick = { lenIdx = i }, label = { Text(c.first, fontSize = 12.sp) })
                }
            }
        }
        Text(
            if (drums) "Tap a square to add a hit, tap it again to remove it." else "Tap an empty cell to add a note, tap a note to remove it.",
            color = Soft, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp),
        )

        Row(Modifier.weight(1f).fillMaxWidth().padding(top = 6.dp)) {
            // key labels, scrolled together with the grid
            Column(Modifier.width(KeysW).fillMaxHeight().verticalScroll(vScroll)) {
                for (p in rows) {
                    val label = if (drums) drumRows.first { it.first == p }.second else pitchName(p)
                    val bg = if (drums) Panel else if (isBlack(p)) Color(0xFF1B1F2B) else Color(0xFFD9DCE8)
                    Box(Modifier.width(KeysW).height(CellH).background(bg), contentAlignment = Alignment.CenterStart) {
                        Text(label, fontSize = 10.sp, color = if (drums || isBlack(p)) Soft else Color(0xFF30344A), modifier = Modifier.padding(start = 6.dp), maxLines = 1)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight().horizontalScroll(hScroll).verticalScroll(vScroll)) {
                Canvas(
                    Modifier.width(gridW).height(gridH)
                        .pointerInput(project.bars, ti, lenIdx, drums, track.notes) {
                            detectTapGestures { off ->
                                val cw = CellW.toPx()
                                val ch = CellH.toPx()
                                val step = (off.x / cw).toInt().coerceIn(0, steps - 1)
                                val row = (off.y / ch).toInt().coerceIn(0, rows.size - 1)
                                val pitch = rows[row]
                                val tick = step * STEP
                                val hit = track.notes.firstOrNull { it.pitch == pitch && tick >= it.start && tick < it.start + it.len }
                                if (hit != null) {
                                    project.removeNote(ti, hit)
                                } else {
                                    val len = if (drums) STEP else lengthChoices[lenIdx].second
                                    project.addNote(ti, NoteM(tick, len, pitch, 100))
                                    NativeEngine.nativeNoteOn(ti, pitch, 0.8f)
                                    scope.launch {
                                        delay(if (drums) 60L else 250L)
                                        NativeEngine.nativeNoteOff(ti, pitch)
                                    }
                                }
                            }
                        },
                ) {
                    val cw = CellW.toPx()
                    val ch = CellH.toPx()
                    // rows
                    for ((r, p) in rows.withIndex()) {
                        val y = r * ch
                        val shade = if (drums) (if (r % 2 == 0) Color(0xFF10131B) else Color(0xFF0D0F16)) else if (isBlack(p)) Color(0xFF0E1017) else Color(0xFF131621)
                        drawRect(shade, Offset(0f, y), Size(size.width, ch))
                        if (!drums && p % 12 == 0) drawLine(Color(0x33FFFFFF), Offset(0f, y + ch), Offset(size.width, y + ch), strokeWidth = 1f)
                    }
                    // columns: step, beat and bar lines
                    for (s in 0..steps) {
                        val x = s * cw
                        val c = if (s % 16 == 0) Color(0x66FFFFFF) else if (s % 4 == 0) Color(0x33FFFFFF) else Color(0x14FFFFFF)
                        drawLine(c, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    }
                    // notes
                    for (n in track.notes) {
                        val row = rows.indexOf(n.pitch)
                        if (row < 0) continue
                        val x = n.start.toFloat() / STEP * cw
                        val w = maxOf(n.len.toFloat() / STEP * cw - 2f, 6f)
                        drawRoundRect(color, Offset(x + 1f, row * ch + 2f), Size(w, ch - 4f), CornerRadius(5f))
                    }
                    // playhead
                    val px = (live.beats * 4.0 * cw).toFloat()
                    drawLine(Color(0xFFFF6B8B), Offset(px, 0f), Offset(px, size.height), strokeWidth = 2f)
                }
            }
        }

        // row names under the grid so they are readable text
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (drums) "Rows: Crash, Open hat, Hat, Clap, Snare, Rim, Tom, Kick" else "Range C2 to C6, scroll up and down", color = Soft, fontSize = 11.sp)
            OutlinedButton(onClick = { project.clearTrack(ti) }) { Text("Clear", fontSize = 12.sp) }
        }
    }
}
