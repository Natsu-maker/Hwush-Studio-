package com.hwush.studio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

private val pads = listOf(
    Triple("Kick", 36, Color(0xFFFF6B8B)),
    Triple("Snare", 38, Color(0xFFFFB86B)),
    Triple("Clap", 39, Color(0xFFFFE06B)),
    Triple("Hat", 42, Color(0xFF6BFFB0)),
    Triple("Open hat", 46, Color(0xFF6BE0FF)),
    Triple("Tom", 45, Color(0xFF6B9BFF)),
    Triple("Rim", 37, Color(0xFFB08BFF)),
    Triple("Crash", 49, Color(0xFFFF8BE0)),
)

/** Play the selected track live: a keyboard for synth tracks, pads for drum tracks. */
@Composable
fun PlayScreen(project: ProjectState) {
    var octave by remember { mutableIntStateOf(4) }
    val ti = project.selected.coerceIn(0, (project.tracks.size - 1).coerceAtLeast(0))
    val track = project.tracks.getOrNull(ti)

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth > 600.dp
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (track == null) "No track" else "Playing: ${track.name}  (pick another track on the Arrange tab)",
                color = Soft, fontSize = 13.sp,
            )
            if (track != null && track.kind == 1) {
                Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (row in 0 until 2) {
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            for (col in 0 until 4) {
                                val p = pads[row * 4 + col]
                                Pad(p.first, p.second, p.third, ti, Modifier.weight(1f).fillMaxSize())
                            }
                        }
                    }
                }
            } else {
                Box(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { if (octave > 1) octave-- }) { Text("Oct -") }
                    Text("C$octave", color = Soft, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = { if (octave < 6) octave++ }) { Text("Oct +") }
                }
                Piano(
                    track = ti,
                    basePitch = (octave + 1) * 12,
                    whiteCount = if (wide) 15 else 10,
                    modifier = Modifier.fillMaxWidth().height(if (wide) 220.dp else 190.dp),
                )
            }
        }
    }
}

@Composable
private fun Pad(label: String, note: Int, color: Color, track: Int, modifier: Modifier) {
    var down by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (down) color else color.copy(alpha = 0.18f))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.6f)), shape)
            .pointerInput(note, track) {
                awaitEachGesture {
                    awaitFirstDown()
                    down = true
                    NativeEngine.nativeNoteOn(track, note, 0.9f)
                    waitForUpOrCancellation()
                    down = false
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (down) Bg else Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

private val whiteSteps = intArrayOf(0, 2, 4, 5, 7, 9, 11)

@Composable
private fun Piano(track: Int, basePitch: Int, whiteCount: Int, modifier: Modifier) {
    var pressed by remember { mutableStateOf(setOf<Int>()) }

    fun whitePitch(i: Int) = basePitch + (i / 7) * 12 + whiteSteps[i % 7]
    fun hasBlack(i: Int) = i < whiteCount - 1 && (i % 7 == 0 || i % 7 == 1 || i % 7 == 3 || i % 7 == 4 || i % 7 == 5)

    fun keyAt(x: Float, y: Float, w: Float, h: Float): Int {
        val kw = w / whiteCount
        val wi = (x / kw).toInt().coerceIn(0, whiteCount - 1)
        if (y < h * 0.6f) {
            for (i in intArrayOf(wi - 1, wi)) {
                if (i >= 0 && hasBlack(i) && abs(x - (i + 1) * kw) < kw * 0.3f) return whitePitch(i) + 1
            }
        }
        return whitePitch(wi)
    }

    Canvas(
        modifier.pointerInput(track, basePitch, whiteCount) {
            val active = HashMap<Long, Int>()
            try {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        for (c in event.changes) {
                            val id = c.id.value
                            val prev = active[id]
                            if (c.pressed) {
                                val k = keyAt(c.position.x, c.position.y, size.width.toFloat(), size.height.toFloat())
                                if (prev == null) {
                                    active[id] = k
                                    NativeEngine.nativeNoteOn(track, k, 0.85f)
                                } else if (prev != k) {
                                    NativeEngine.nativeNoteOff(track, prev)
                                    active[id] = k
                                    NativeEngine.nativeNoteOn(track, k, 0.85f)
                                }
                            } else if (prev != null) {
                                NativeEngine.nativeNoteOff(track, prev)
                                active.remove(id)
                            }
                            c.consume()
                        }
                        pressed = active.values.toSet()
                    }
                }
            } finally {
                for (k in active.values) NativeEngine.nativeNoteOff(track, k)
            }
        },
    ) {
        val kw = size.width / whiteCount
        for (i in 0 until whiteCount) {
            val on = pressed.contains(whitePitch(i))
            drawRect(
                color = if (on) Accent else Ink,
                topLeft = Offset(i * kw + 1f, 0f),
                size = Size(kw - 2f, size.height),
            )
        }
        for (i in 0 until whiteCount) {
            if (!hasBlack(i)) continue
            val on = pressed.contains(whitePitch(i) + 1)
            drawRect(
                color = if (on) Accent else Color(0xFF1B1F2B),
                topLeft = Offset((i + 1) * kw - kw * 0.3f, 0f),
                size = Size(kw * 0.6f, size.height * 0.6f),
            )
        }
    }
}
