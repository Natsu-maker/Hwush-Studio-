package com.hwush.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BarWidth = 150.dp
private val RowHeight = 76.dp
private val RulerHeight = 28.dp
private val HeaderWidth = 118.dp

@Composable
fun ArrangeScreen(project: ProjectState, live: LiveState, onOpenRoll: () -> Unit) {
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    var addMenu by remember { mutableStateOf(false) }
    val totalWidth: Dp = BarWidth * project.bars

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                OutlinedButton(onClick = { addMenu = true }) { Text("+ Track") }
                DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                    for (p in presetNames.indices) {
                        DropdownMenuItem(text = { Text(presetNames[p]) }, onClick = { addMenu = false; project.addTrack(0, p) })
                    }
                    DropdownMenuItem(text = { Text("Drums") }, onClick = { addMenu = false; project.addTrack(1, 0) })
                }
            }
            Text("Bars", color = Soft, fontSize = 13.sp)
            OutlinedButton(onClick = { project.setBars(project.bars - 1) }) { Text("-") }
            Text("${project.bars}", color = Ink, fontWeight = FontWeight.SemiBold)
            OutlinedButton(onClick = { project.setBars(project.bars + 1) }) { Text("+") }
        }

        Row(Modifier.weight(1f).fillMaxWidth()) {
            // track headers
            Column(Modifier.width(HeaderWidth)) {
                Spacer(Modifier.height(RulerHeight))
                Column(Modifier.weight(1f).verticalScroll(vScroll)) {
                    project.tracks.forEachIndexed { i, t ->
                        TrackHeader(project, i, t)
                    }
                }
            }
            // ruler and lanes
            Box(Modifier.weight(1f).fillMaxHeight().horizontalScroll(hScroll)) {
                Column(Modifier.width(totalWidth).fillMaxHeight()) {
                    Ruler(project, totalWidth)
                    Column(Modifier.weight(1f).verticalScroll(vScroll)) {
                        project.tracks.forEachIndexed { i, t ->
                            Lane(project, i, t, onOpenRoll)
                        }
                    }
                }
                // playhead drawn over everything
                Canvas(Modifier.width(totalWidth).fillMaxHeight()) {
                    val x = (live.beats / 4.0 * BarWidth.toPx()).toFloat()
                    drawLine(Color(0xFFFF6B8B), Offset(x, 0f), Offset(x, size.height), strokeWidth = 2.dp.toPx())
                }
            }
        }
    }
}

@Composable
private fun TrackHeader(project: ProjectState, i: Int, t: TrackM) {
    val sel = project.selected == i
    val color = trackColor(t.colorIdx)
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxWidth().height(RowHeight)
            .background(if (sel) PanelHi else Panel)
            .clickable { project.selected = i },
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(color))
        Column(Modifier.padding(start = 10.dp, top = 6.dp, end = 4.dp)) {
            Text(t.name, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                ToggleBox("M", t.mute, Color(0xFFFFB86B), { project.toggleMute(i) }, 28.dp)
                ToggleBox("S", t.solo, Color(0xFF6BFFB0), { project.toggleSolo(i) }, 28.dp)
                Box {
                    ToggleBox("⋮", false, Accent, { menu = true }, 28.dp)
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (t.kind == 0) {
                            for (p in presetNames.indices) {
                                DropdownMenuItem(text = { Text("Sound: ${presetNames[p]}") }, onClick = { menu = false; project.setPreset(i, p) })
                            }
                        }
                        DropdownMenuItem(text = { Text("Clear notes") }, onClick = { menu = false; project.clearTrack(i) })
                        DropdownMenuItem(text = { Text("Delete track") }, onClick = { menu = false; project.deleteTrack(i) })
                    }
                }
            }
        }
    }
}

@Composable
private fun Ruler(project: ProjectState, totalWidth: Dp) {
    Row(
        Modifier.width(totalWidth).height(RulerHeight).background(Panel)
            .pointerInput(project.bars) {
                detectTapGestures { off ->
                    NativeEngine.nativeSeekBeats(off.x / BarWidth.toPx() * 4.0)
                }
            },
    ) {
        for (b in 0 until project.bars) {
            Box(Modifier.width(BarWidth).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                Text("${b + 1}", color = Soft, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}

@Composable
private fun Lane(project: ProjectState, i: Int, t: TrackM, onOpenRoll: () -> Unit) {
    val sel = project.selected == i
    val color = trackColor(t.colorIdx)
    Canvas(
        Modifier.fillMaxWidth().height(RowHeight)
            .background(if (sel) PanelHi else Bg)
            .pointerInput(i) {
                detectTapGestures { project.selected = i; onOpenRoll() }
            },
    ) {
        val bw = BarWidth.toPx()
        val h = size.height
        // bar and beat lines
        for (b in 0..project.bars) {
            drawLine(Color(0x33FFFFFF), Offset(b * bw, 0f), Offset(b * bw, h), strokeWidth = 1.dp.toPx())
        }
        for (q in 0 until project.bars * 4) {
            if (q % 4 != 0) drawLine(Color(0x12FFFFFF), Offset(q * bw / 4f, 0f), Offset(q * bw / 4f, h), strokeWidth = 1.dp.toPx())
        }
        // the clip
        val clipAlpha = if (t.mute) 0.12f else 0.28f
        drawRoundRect(
            color.copy(alpha = clipAlpha), Offset(2f, 6.dp.toPx()), Size(bw * project.bars - 4f, h - 12.dp.toPx()),
            CornerRadius(8.dp.toPx()),
        )
        // tiny preview of the notes
        val lo: Int
        val hi: Int
        if (t.kind == 1) { lo = 35; hi = 52 } else {
            var mn = 127; var mx = 0
            for (n in t.notes) { if (n.pitch < mn) mn = n.pitch; if (n.pitch > mx) mx = n.pitch }
            if (t.notes.isEmpty()) { mn = 60; mx = 72 }
            lo = mn - 1; hi = maxOf(mx + 1, mn + 8)
        }
        val top = 12.dp.toPx()
        val area = h - 24.dp.toPx()
        val noteH = maxOf(2.dp.toPx(), area / (hi - lo + 1))
        val pxPerTick = bw / TICKS_PER_BAR
        for (n in t.notes) {
            val y = top + (hi - n.pitch).toFloat() / (hi - lo + 1) * area
            drawRect(
                color.copy(alpha = if (t.mute) 0.4f else 1f),
                Offset(n.start * pxPerTick, y),
                Size(maxOf(n.len * pxPerTick, 2.dp.toPx()), noteH),
            )
        }
    }
}
