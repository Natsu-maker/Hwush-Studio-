package com.hwush.studio

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

const val PPQ = 960
const val TICKS_PER_BAR = PPQ * 4
const val STEP = PPQ / 4            // one sixteenth note, in ticks
const val MAX_TRACKS = 16

val presetNames = listOf("Saw lead", "Soft pad", "Pluck", "Sub bass")

/** One note. Times are in ticks, 960 per quarter note. */
data class NoteM(val start: Int, val len: Int, val pitch: Int, val vel: Int = 100)

/** kind 0 = synth, 1 = drums. Each track holds one pattern that spans the whole project. */
data class TrackM(
    val name: String,
    val kind: Int,
    val preset: Int,
    val colorIdx: Int,
    val vol: Float = 0.8f,
    val pan: Float = 0f,
    val mute: Boolean = false,
    val solo: Boolean = false,
    val notes: List<NoteM> = emptyList(),
)

/** Values the UI reads many times a second, kept apart so only the parts that show them redraw. */
class LiveState {
    var beats by mutableDoubleStateOf(0.0)
    var playing by mutableStateOf(false)
    var load by mutableFloatStateOf(0f)
    var latency by mutableFloatStateOf(0f)
    var xruns by mutableIntStateOf(0)
    var masterPeak by mutableFloatStateOf(0f)
}

class ProjectState {
    var bpm by mutableFloatStateOf(120f)
    var bars by mutableIntStateOf(4)
    var loop by mutableStateOf(true)
    var metronome by mutableStateOf(false)
    var master by mutableFloatStateOf(0.85f)
    var tracks by mutableStateOf(listOf<TrackM>())
    var selected by mutableIntStateOf(0)
    var version by mutableIntStateOf(0)       // goes up on every change so autosave knows when to write
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)

    private class Snap(val tracks: List<TrackM>, val bars: Int)

    private val undoStack = ArrayList<Snap>()
    private val redoStack = ArrayList<Snap>()

    // ---------------- sending to the engine ----------------
    private fun syncTrack(i: Int) {
        val t = tracks[i]
        val flat = IntArray(t.notes.size * 4)
        for ((k, n) in t.notes.withIndex()) {
            flat[k * 4] = n.start
            flat[k * 4 + 1] = n.len
            flat[k * 4 + 2] = n.pitch
            flat[k * 4 + 3] = n.vel
        }
        NativeEngine.nativeSetTrack(i, t.kind, t.preset, t.vol, t.pan, t.mute, t.solo, bars * TICKS_PER_BAR, flat)
    }

    fun syncAll() {
        NativeEngine.nativeSetTrackCount(tracks.size)
        for (i in tracks.indices) syncTrack(i)
        NativeEngine.nativeSetTempo(bpm)
        NativeEngine.nativeSetLoop(loop, bars)
        NativeEngine.nativeSetMetronome(metronome)
        NativeEngine.nativeSetMaster(master)
    }

    // ---------------- editing ----------------
    private fun refreshUndo() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun edit(newTracks: List<TrackM>, newBars: Int = bars, remember: Boolean = true) {
        if (remember) {
            undoStack.add(Snap(tracks, bars))
            if (undoStack.size > 60) undoStack.removeAt(0)
            redoStack.clear()
        }
        val old = tracks
        val countChanged = newTracks.size != old.size
        val barsChanged = newBars != bars
        tracks = newTracks
        bars = newBars
        if (selected >= tracks.size) selected = (tracks.size - 1).coerceAtLeast(0)
        if (countChanged || barsChanged) {
            syncAll()
        } else {
            for (i in newTracks.indices) if (newTracks[i] !== old[i]) syncTrack(i)
        }
        refreshUndo()
        version++
    }

    private fun replace(i: Int, t: TrackM, remember: Boolean = true) {
        if (i !in tracks.indices) return
        val list = tracks.toMutableList()
        list[i] = t
        edit(list, bars, remember)
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(Snap(tracks, bars))
        val s = undoStack.removeAt(undoStack.size - 1)
        tracks = s.tracks
        bars = s.bars
        if (selected >= tracks.size) selected = (tracks.size - 1).coerceAtLeast(0)
        syncAll()
        refreshUndo()
        version++
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(Snap(tracks, bars))
        val s = redoStack.removeAt(redoStack.size - 1)
        tracks = s.tracks
        bars = s.bars
        if (selected >= tracks.size) selected = (tracks.size - 1).coerceAtLeast(0)
        syncAll()
        refreshUndo()
        version++
    }

    fun addNote(ti: Int, n: NoteM) {
        val t = tracks.getOrNull(ti) ?: return
        replace(ti, t.copy(notes = t.notes + n))
    }

    fun removeNote(ti: Int, n: NoteM) {
        val t = tracks.getOrNull(ti) ?: return
        replace(ti, t.copy(notes = t.notes - n))
    }

    fun clearTrack(ti: Int) {
        val t = tracks.getOrNull(ti) ?: return
        replace(ti, t.copy(notes = emptyList()))
    }

    fun addTrack(kind: Int, preset: Int) {
        if (tracks.size >= MAX_TRACKS) return
        val base = if (kind == 1) "Drums" else presetNames[preset.coerceIn(0, presetNames.size - 1)]
        val same = tracks.count { it.kind == kind && (kind == 1 || it.preset == preset) }
        val name = if (same == 0) base else "$base ${same + 1}"
        val vol = if (kind == 1) 0.8f else 0.75f
        edit(tracks + TrackM(name, kind, preset, tracks.size % 8, vol))
        selected = tracks.size - 1
    }

    fun deleteTrack(i: Int) {
        if (tracks.size <= 1 || i !in tracks.indices) return
        val list = tracks.toMutableList()
        list.removeAt(i)
        edit(list)
    }

    fun setPreset(i: Int, preset: Int) {
        val t = tracks.getOrNull(i) ?: return
        if (t.kind == 1) return
        replace(i, t.copy(preset = preset, name = presetNames[preset.coerceIn(0, presetNames.size - 1)]))
    }

    fun setVol(i: Int, v: Float) { tracks.getOrNull(i)?.let { replace(i, it.copy(vol = v), false) }; version++ }
    fun setPan(i: Int, v: Float) { tracks.getOrNull(i)?.let { replace(i, it.copy(pan = v), false) }; version++ }
    fun toggleMute(i: Int) { tracks.getOrNull(i)?.let { replace(i, it.copy(mute = !it.mute), false) }; version++ }
    fun toggleSolo(i: Int) { tracks.getOrNull(i)?.let { replace(i, it.copy(solo = !it.solo), false) }; version++ }

    fun changeBars(n: Int) {
        val v = n.coerceIn(1, 64)
        if (v != bars) edit(tracks, v)
    }

    fun changeBpm(v: Float) {
        bpm = v.coerceIn(40f, 240f)
        NativeEngine.nativeSetTempo(bpm)
        version++
    }

    fun toggleLoop() {
        loop = !loop
        NativeEngine.nativeSetLoop(loop, bars)
        version++
    }

    fun toggleMetronome() {
        metronome = !metronome
        NativeEngine.nativeSetMetronome(metronome)
        version++
    }

    fun changeMaster(v: Float) {
        master = v
        NativeEngine.nativeSetMaster(master)
        version++
    }

    // ---------------- projects ----------------
    private fun resetHistory() {
        undoStack.clear()
        redoStack.clear()
        refreshUndo()
    }

    fun newProject() {
        bpm = 120f; bars = 4; loop = true; metronome = false; master = 0.85f
        tracks = listOf(
            TrackM("Saw lead", 0, 0, 0, 0.75f),
            TrackM("Drums", 1, 0, 3, 0.8f),
        )
        selected = 0
        resetHistory()
        NativeEngine.nativeSeekBeats(0.0)
        syncAll()
        version++
    }

    fun loadDemo() {
        fun nm(beat: Double, len: Double, pitch: Int, vel: Float) =
            NoteM((beat * PPQ + 0.5).toInt(), (len * PPQ + 0.5).toInt(), pitch, (vel * 127).toInt())

        val drums = ArrayList<NoteM>()
        val bass = ArrayList<NoteM>()
        val pad = ArrayList<NoteM>()
        val lead = ArrayList<NoteM>()
        val root = intArrayOf(57, 53, 60, 55)
        val third = intArrayOf(60, 57, 64, 59)
        val fifth = intArrayOf(64, 60, 67, 62)
        val bars = 8
        for (bar in 0 until bars) {
            val b0 = bar * 4.0
            for (beat in 0 until 4) drums.add(nm(b0 + beat, 0.25, 36, 1.0f))
            drums.add(nm(b0 + 1, 0.25, 38, 0.95f)); drums.add(nm(b0 + 3, 0.25, 38, 0.95f))
            drums.add(nm(b0 + 1, 0.25, 39, 0.5f)); drums.add(nm(b0 + 3, 0.25, 39, 0.5f))
            for (e in 0 until 8) {
                val pos = b0 + e * 0.5
                if (e == 7) drums.add(nm(pos, 0.25, 46, 0.6f))
                else drums.add(nm(pos, 0.25, 42, if (e % 2 == 1) 0.45f else 0.75f))
            }
            if (bar == bars - 1) {
                drums.add(nm(b0 + 3.0, 0.25, 50, 0.9f)); drums.add(nm(b0 + 3.25, 0.25, 48, 0.9f))
                drums.add(nm(b0 + 3.5, 0.25, 45, 0.9f)); drums.add(nm(b0 + 3.75, 0.25, 41, 0.9f))
            }
            val ch = (bar / 2) % 4
            val r = root[ch] - 24
            bass.add(nm(b0, 0.75, r, 1.0f)); bass.add(nm(b0 + 1.5, 0.5, r, 0.8f))
            bass.add(nm(b0 + 2.0, 0.75, r, 0.95f)); bass.add(nm(b0 + 3.5, 0.5, r + 12, 0.8f))
            if (bar >= 2) {
                val tones = intArrayOf(root[ch] + 12, third[ch] + 12, fifth[ch] + 12, third[ch] + 12)
                for (e in 0 until 8) lead.add(nm(b0 + e * 0.5, 0.4, tones[e % 4], 0.7f + (if (e % 2 == 0) 0.15f else 0f)))
            }
        }
        for (ch in 0 until 4) {
            val b0 = ch * 8.0
            pad.add(nm(b0, 7.8, root[ch], 0.7f)); pad.add(nm(b0, 7.8, third[ch], 0.7f)); pad.add(nm(b0, 7.8, fifth[ch], 0.7f))
        }
        this.bpm = 120f; this.bars = 8; loop = true; metronome = false; master = 0.85f
        tracks = listOf(
            TrackM("Drums", 1, 0, 3, 0.8f, 0f, false, false, drums),
            TrackM("Sub bass", 0, 3, 1, 0.8f, 0f, false, false, bass),
            TrackM("Soft pad", 0, 1, 4, 0.7f, -0.3f, false, false, pad),
            TrackM("Pluck", 0, 2, 5, 0.6f, 0.3f, false, false, lead),
        )
        selected = 0
        resetHistory()
        NativeEngine.nativeSeekBeats(0.0)
        syncAll()
        version++
    }

    // ---------------- saving ----------------
    fun save(file: File) {
        val o = JSONObject()
        o.put("format", 1)
        o.put("bpm", bpm.toDouble())
        o.put("bars", bars)
        o.put("loop", loop)
        o.put("master", master.toDouble())
        val arr = JSONArray()
        for (t in tracks) {
            val to = JSONObject()
            to.put("name", t.name)
            to.put("kind", t.kind)
            to.put("preset", t.preset)
            to.put("color", t.colorIdx)
            to.put("vol", t.vol.toDouble())
            to.put("pan", t.pan.toDouble())
            to.put("mute", t.mute)
            to.put("solo", t.solo)
            val na = JSONArray()
            for (n in t.notes) {
                val one = JSONArray()
                one.put(n.start); one.put(n.len); one.put(n.pitch); one.put(n.vel)
                na.put(one)
            }
            to.put("notes", na)
            arr.put(to)
        }
        o.put("tracks", arr)
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(o.toString())
        if (!tmp.renameTo(file)) {
            file.writeText(o.toString())
            tmp.delete()
        }
    }

    /** Returns true if a saved project was read. Otherwise starts a fresh one. */
    fun load(file: File): Boolean {
        try {
            if (file.exists()) {
                val o = JSONObject(file.readText())
                val list = ArrayList<TrackM>()
                val arr = o.getJSONArray("tracks")
                for (i in 0 until arr.length()) {
                    val to = arr.getJSONObject(i)
                    val na = to.getJSONArray("notes")
                    val notes = ArrayList<NoteM>()
                    for (k in 0 until na.length()) {
                        val one = na.getJSONArray(k)
                        notes.add(NoteM(one.getInt(0), one.getInt(1), one.getInt(2), one.getInt(3)))
                    }
                    list.add(
                        TrackM(
                            to.getString("name"), to.getInt("kind"), to.getInt("preset"), to.getInt("color"),
                            to.getDouble("vol").toFloat(), to.getDouble("pan").toFloat(),
                            to.getBoolean("mute"), to.getBoolean("solo"), notes,
                        ),
                    )
                }
                if (list.isNotEmpty()) {
                    bpm = o.getDouble("bpm").toFloat()
                    bars = o.getInt("bars")
                    loop = o.getBoolean("loop")
                    master = o.getDouble("master").toFloat()
                    metronome = false
                    tracks = list
                    selected = 0
                    resetHistory()
                    syncAll()
                    return true
                }
            }
        } catch (e: Exception) {
            // a damaged file must never stop the app from opening
        }
        newProject()
        return false
    }
}
