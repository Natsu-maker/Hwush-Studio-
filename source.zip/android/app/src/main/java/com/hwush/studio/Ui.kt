package com.hwush.studio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF0B0D12)
val Panel = Color(0xFF151823)
val PanelHi = Color(0xFF1D2130)
val Accent = Color(0xFF8B7CFF)
val Soft = Color(0xFF9AA0B4)
val Ink = Color(0xFFE8EAF2)

val trackColors = listOf(
    Color(0xFF8B7CFF), Color(0xFF6BFFB0), Color(0xFFFFB86B), Color(0xFFFF6B8B),
    Color(0xFF6BE0FF), Color(0xFFFF8BE0), Color(0xFFFFE06B), Color(0xFF6B9BFF),
)

fun trackColor(i: Int): Color = trackColors[((i % trackColors.size) + trackColors.size) % trackColors.size]

@Composable
fun StudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel,
            onSurface = Ink,
            onBackground = Ink,
            surfaceVariant = PanelHi,
        ),
        content = content,
    )
}

/** Small square on/off button used for Mute and Solo. */
@Composable
fun ToggleBox(label: String, on: Boolean, color: Color, onClick: () -> Unit, size: Dp = 30.dp) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier
            .size(size)
            .clip(shape)
            .background(if (on) color else Color.Transparent)
            .border(BorderStroke(1.dp, if (on) color else Soft.copy(alpha = 0.5f)), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (on) Bg else Soft, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
