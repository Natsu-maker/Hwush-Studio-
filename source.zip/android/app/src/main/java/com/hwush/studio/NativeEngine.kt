package com.hwush.studio

/** Thin Kotlin face of the C++ engine. Every call returns immediately; audio runs on its own thread. */
object NativeEngine {
    init {
        System.loadLibrary("hwstudio")
    }

    external fun nativeStart(): Boolean
    external fun nativeStop()
    external fun nativeNoteOn(track: Int, pitch: Int, velocity: Float)
    external fun nativeNoteOff(track: Int, pitch: Int)
    external fun nativeSetTrackCount(count: Int)
    external fun nativeSetTrack(
        index: Int, kind: Int, preset: Int, volume: Float, pan: Float,
        mute: Boolean, solo: Boolean, lenTicks: Int, notes: IntArray,
    )
    external fun nativeSetTempo(bpm: Float)
    external fun nativeSetLoop(on: Boolean, bars: Int)
    external fun nativeSetMetronome(on: Boolean)
    external fun nativeSetMaster(gain: Float)
    external fun nativePlay()
    external fun nativePause()
    external fun nativeSeekBeats(beats: Double)
    external fun nativeIsPlaying(): Boolean
    external fun nativePositionBeats(): Double
    external fun nativeMasterPeak(): Float
    external fun nativeTrackPeak(index: Int): Float
    external fun nativeDspLoad(): Float
    external fun nativeXruns(): Int
    external fun nativeLatencyMs(): Float
}
