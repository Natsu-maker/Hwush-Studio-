package com.hwush.studio

/** Thin Kotlin face of the C++ engine. Every call returns immediately; audio runs on its own thread. */
object NativeEngine {
    init {
        System.loadLibrary("hwstudio")
    }

    external fun nativeStart(): Boolean
    external fun nativeStop()
    external fun nativeKeyOn(pitch: Int, velocity: Float)
    external fun nativeKeyOff(pitch: Int)
    external fun nativePadOn(note: Int, velocity: Float)
    external fun nativeSetPreset(preset: Int)
    external fun nativeLoadDemo(demo: Boolean)
    external fun nativePlay()
    external fun nativePause()
    external fun nativeRewind()
    external fun nativeIsPlaying(): Boolean
    external fun nativePositionBeats(): Double
    external fun nativeMasterPeak(): Float
    external fun nativeDspLoad(): Float
    external fun nativeXruns(): Int
    external fun nativeLatencyMs(): Float
}
