package com.hwush.studio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun MixerScreen(project: ProjectState, live: LiveState) {
    var peaks by remember { mutableStateOf(FloatArray(MAX_TRACKS)) }
    LaunchedEffect(Unit) {
        while (true) {
            val p = FloatArray(MAX_TRACKS)
            for (i in 0 until MAX_TRACKS) p[i] = NativeEngine.nativeTrackPeak(i)
            peaks = p
            delay(50)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        project.tracks.forEachIndexed { i, t ->
            val color = trackColor(t.colorIdx)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.width(10.dp).height(10.dp).clip(RoundedCornerShape(5.dp)).background(color))
                        Text(t.name, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ToggleBox("M", t.mute, Color(0xFFFFB86B), { project.toggleMute(i) })
                        ToggleBox("S", t.solo, Color(0xFF6BFFB0), { project.toggleSolo(i) })
                    }
                }
                Meter(peaks[i], color)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Vol", color = Soft, fontSize = 12.sp, modifier = Modifier.width(32.dp))
                    Slider(
                        value = t.vol, onValueChange = { project.setVol(i, it) }, valueRange = 0f..1.2f,
                        colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Pan", color = Soft, fontSize = 12.sp, modifier = Modifier.width(32.dp))
                    Slider(
                        value = t.pan, onValueChange = { project.setPan(i, it) }, valueRange = -1f..1f,
                        colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PanelHi).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text("Master", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Meter(live.masterPeak, Accent)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Vol", color = Soft, fontSize = 12.sp, modifier = Modifier.width(32.dp))
                Slider(value = project.master, onValueChange = { project.setMaster(it) }, valueRange = 0f..1.2f, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Meter(level: Float, color: Color) {
    Canvas(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF0B0D12))) {
        val w = size.width * level.coerceIn(0f, 1f)
        drawRect(if (level > 0.95f) Color(0xFFFF6B8B) else color, Offset(0f, 0f), Size(w, size.height))
    }
}
