// Bridge between the Kotlin UI and the portable engine. Owns the Oboe output stream.
#include <jni.h>
#include <cstring>
#include <oboe/Oboe.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <memory>
#include "hw/engine.h"
#include "song.h"

namespace {

constexpr int kRate = 48000;

hw::SynthParams makePreset(int p) {
  hw::SynthParams s;
  switch (p) {
    case 1:  // soft pad
      s.osc2Detune = 12; s.osc2Level = 0.8f; s.cutoff = 1800; s.resonance = 0.15f;
      s.ampA = 0.3f; s.ampS = 0.9f; s.ampR = 1.0f; s.gain = 0.22f; s.voices = 12;
      break;
    case 2:  // pluck
      s.osc1 = hw::Wave::Square; s.osc2 = hw::Wave::Saw; s.osc2Level = 0.4f; s.osc2Detune = 9;
      s.cutoff = 1500; s.resonance = 0.3f; s.filterEnvAmt = 2.5f; s.fltD = 0.25f; s.fltS = 0.1f;
      s.ampD = 0.25f; s.ampS = 0.15f; s.ampR = 0.2f; s.gain = 0.35f;
      break;
    case 3:  // sub bass
      s.osc2 = hw::Wave::Square; s.osc2Level = 0.3f; s.osc2Detune = 4; s.subLevel = 0.8f;
      s.cutoff = 450; s.resonance = 0.25f; s.filterEnvAmt = 1.5f; s.fltD = 0.15f; s.fltS = 0.2f;
      s.ampS = 0.8f; s.ampR = 0.08f; s.gain = 0.6f;
      break;
    default:  // saw lead
      s.cutoff = 5000; s.filterEnvAmt = 1.0f; s.ampD = 0.3f; s.ampS = 0.6f; s.gain = 0.35f;
      break;
  }
  return s;
}

struct Host : oboe::AudioStreamDataCallback {
  hw::Engine engine{double(kRate)};
  std::shared_ptr<oboe::AudioStream> stream;
  hw::Snapshot cur;
  int keysTrack = 1;
  int preset = 0;
  bool demo = false;
  std::atomic<float> load{0.f};

  Host() { rebuild(); }

  void rebuild() {
    if (demo) {
      cur = hw::demoSong();
    } else {
      cur = hw::Snapshot();
      hw::Track d;
      d.name = "Drums"; d.kind = hw::InstrumentKind::Drums; d.volume = 0.8f;
      cur.tracks.push_back(d);
    }
    hw::Track k;
    k.name = "Keys";
    k.synth = makePreset(preset);
    cur.tracks.push_back(k);
    keysTrack = int(cur.tracks.size()) - 1;
    cur.masterGain = 0.85f;
    engine.setLoop(demo, 0, hw::Tick(8) * 4 * hw::kPpq);
    engine.publish(std::make_shared<const hw::Snapshot>(cur));
  }

  void applyPreset(int p) {
    preset = p;
    cur.tracks[size_t(keysTrack)].synth = makePreset(p);
    engine.publish(std::make_shared<const hw::Snapshot>(cur));
  }

  oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* data, int32_t frames) override {
    auto t0 = std::chrono::steady_clock::now();
    engine.render(static_cast<float*>(data), frames);
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    float l = float(dt / (double(frames) / kRate));
    load.store(std::max(l, load.load() * 0.97f));
    return oboe::DataCallbackResult::Continue;
  }
};

std::shared_ptr<Host> g_host;

}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_hwush_studio_NativeEngine_nativeStart(JNIEnv*, jobject) {
  if (!g_host) g_host = std::make_shared<Host>();
  if (g_host->stream) return JNI_TRUE;
  oboe::AudioStreamBuilder b;
  b.setDirection(oboe::Direction::Output)
      ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
      ->setSharingMode(oboe::SharingMode::Exclusive)
      ->setFormat(oboe::AudioFormat::Float)
      ->setChannelCount(oboe::ChannelCount::Stereo)
      ->setSampleRate(kRate)
      ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
      ->setUsage(oboe::Usage::Media)
      ->setDataCallback(g_host);
  oboe::Result r = b.openStream(g_host->stream);
  if (r != oboe::Result::OK || !g_host->stream) { g_host->stream.reset(); return JNI_FALSE; }
  g_host->stream->setBufferSizeInFrames(g_host->stream->getFramesPerBurst() * 2);
  r = g_host->stream->requestStart();
  if (r != oboe::Result::OK) { g_host->stream->close(); g_host->stream.reset(); return JNI_FALSE; }
  return JNI_TRUE;
}

JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativeStop(JNIEnv*, jobject) {
  if (g_host && g_host->stream) {
    g_host->stream->stop();
    g_host->stream->close();
    g_host->stream.reset();
  }
}

JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativeKeyOn(JNIEnv*, jobject, jint pitch, jfloat vel) {
  if (g_host) g_host->engine.liveNoteOn(g_host->keysTrack, pitch, vel);
}
JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativeKeyOff(JNIEnv*, jobject, jint pitch) {
  if (g_host) g_host->engine.liveNoteOff(g_host->keysTrack, pitch);
}
JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativePadOn(JNIEnv*, jobject, jint note, jfloat vel) {
  if (g_host) g_host->engine.liveNoteOn(0, note, vel);
}
JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativeSetPreset(JNIEnv*, jobject, jint p) {
  if (g_host) g_host->applyPreset(p);
}
JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativeLoadDemo(JNIEnv*, jobject, jboolean demo) {
  if (!g_host) return;
  g_host->demo = demo == JNI_TRUE;
  g_host->engine.stop();
  g_host->rebuild();
  g_host->engine.seekTicks(0);
}
JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativePlay(JNIEnv*, jobject) { if (g_host) g_host->engine.play(); }
JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativePause(JNIEnv*, jobject) { if (g_host) g_host->engine.stop(); }
JNIEXPORT void JNICALL Java_com_hwush_studio_NativeEngine_nativeRewind(JNIEnv*, jobject) { if (g_host) g_host->engine.seekTicks(0); }
JNIEXPORT jboolean JNICALL Java_com_hwush_studio_NativeEngine_nativeIsPlaying(JNIEnv*, jobject) {
  return g_host && g_host->engine.playing() ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jdouble JNICALL Java_com_hwush_studio_NativeEngine_nativePositionBeats(JNIEnv*, jobject) {
  return g_host ? double(g_host->engine.positionTicks()) / hw::kPpq : 0.0;
}
JNIEXPORT jfloat JNICALL Java_com_hwush_studio_NativeEngine_nativeMasterPeak(JNIEnv*, jobject) {
  return g_host ? g_host->engine.masterPeak() : 0.f;
}
JNIEXPORT jfloat JNICALL Java_com_hwush_studio_NativeEngine_nativeDspLoad(JNIEnv*, jobject) {
  return g_host ? g_host->load.load() : 0.f;
}
JNIEXPORT jint JNICALL Java_com_hwush_studio_NativeEngine_nativeXruns(JNIEnv*, jobject) {
  if (!g_host || !g_host->stream) return 0;
  auto r = g_host->stream->getXRunCount();
  return r.error() == oboe::Result::OK ? r.value() : 0;
}
JNIEXPORT jfloat JNICALL Java_com_hwush_studio_NativeEngine_nativeLatencyMs(JNIEnv*, jobject) {
  if (!g_host || !g_host->stream) return 0.f;
  auto r = g_host->stream->calculateLatencyMillis();
  return r.error() == oboe::Result::OK ? float(r.value()) : 0.f;
}

}  // extern "C"
