// Bridge between the Kotlin UI and the portable engine. Owns the Oboe output stream.
#include <jni.h>
#include <cstring>
#include <oboe/Oboe.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <memory>
#include <vector>
#include "hw/engine.h"

namespace {

constexpr int kRate = 48000;
constexpr hw::Tick kBar = hw::Tick(4) * hw::kPpq;

hw::SynthParams makePreset(int p) {
  hw::SynthParams s;
  switch (p) {
    case 1:  // soft pad
      s.osc2Detune = 12; s.osc2Level = 0.8f; s.cutoff = 1800; s.resonance = 0.15f;
      s.ampA = 0.3f; s.ampS = 0.9f; s.ampR = 1.0f; s.gain = 0.22f; s.voices = 12;
      break;
    case 2:  // pluck
      s.osc1 = hw::Wave::Square; s.osc2 = hw::Wave::Saw; s.osc2Level = 0.4f; s.osc2Detune = 9;
      s.cutoff = 1500; s.resonance = 0.3f; s.filterEnvAmt = 2.5f; s.fltD = 0.25f; s.fltS = 0.1f;
      s.ampD = 0.25f; s.ampS = 0.15f; s.ampR = 0.2f; s.gain = 0.35f;
      break;
    case 3:  // sub bass
      s.osc2 = hw::Wave::Square; s.osc2Level = 0.3f; s.osc2Detune = 4; s.subLevel = 0.8f;
      s.cutoff = 450; s.resonance = 0.25f; s.filterEnvAmt = 1.5f; s.fltD = 0.15f; s.fltS = 0.2f;
      s.ampS = 0.8f; s.ampR = 0.08f; s.gain = 0.6f;
      break;
    default:  // saw lead
      s.cutoff = 5000; s.filterEnvAmt = 1.0f; s.ampD = 0.3f; s.ampS = 0.6f; s.gain = 0.35f;
      break;
  }
  return s;
}

struct Host : oboe::AudioStreamDataCallback {
  hw::Engine engine{double(kRate)};
  std::shared_ptr<oboe::AudioStream> stream;
  hw::Snapshot cur;
  std::atomic<float> load{0.f};

  Host() { cur.masterGain = 0.85f; publish(); }

  void publish() { engine.publish(std::make_shared<const hw::Snapshot>(cur)); }

  oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* data, int32_t frames) override {
    auto t0 = std::chrono::steady_clock::now();
    engine.render(static_cast<float*>(data), frames);
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    float l = float(dt / (double(frames) / kRate));
    load.store(std::max(l, load.load() * 0.97f));
    return oboe::DataCallbackResult::Continue;
  }
};

std::shared_ptr<Host> g_host;
Host* H() { if (!g_host) g_host = std::make_shared<Host>(); return g_host.get(); }

}  // namespace

#define JF(ret, name, ...) extern "C" JNIEXPORT ret JNICALL Java_com_hwush_studio_NativeEngine_##name(JNIEnv* env, jobject, ##__VA_ARGS__)

JF(jboolean, nativeStart) {
  (void)env;
  H();
  if (g_host->stream) return JNI_TRUE;
  oboe::AudioStreamBuilder b;
  b.setDirection(oboe::Direction::Output)
      ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
      ->setSharingMode(oboe::SharingMode::Exclusive)
      ->setFormat(oboe::AudioFormat::Float)
      ->setChannelCount(oboe::ChannelCount::Stereo)
      ->setSampleRate(kRate)
      ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
      ->setUsage(oboe::Usage::Media)
      ->setDataCallback(g_host);
  oboe::Result r = b.openStream(g_host->stream);
  if (r != oboe::Result::OK || !g_host->stream) { g_host->stream.reset(); return JNI_FALSE; }
  g_host->stream->setBufferSizeInFrames(g_host->stream->getFramesPerBurst() * 2);
  r = g_host->stream->requestStart();
  if (r != oboe::Result::OK) { g_host->stream->close(); g_host->stream.reset(); return JNI_FALSE; }
  return JNI_TRUE;
}

JF(void, nativeStop) {
  (void)env;
  if (g_host && g_host->stream) {
    g_host->stream->stop();
    g_host->stream->close();
    g_host->stream.reset();
  }
}

JF(void, nativeNoteOn, jint track, jint pitch, jfloat vel) { (void)env; H()->engine.liveNoteOn(track, pitch, vel); }
JF(void, nativeNoteOff, jint track, jint pitch) { (void)env; H()->engine.liveNoteOff(track, pitch); }

JF(void, nativeSetTrackCount, jint n) {
  (void)env;
  H();
  n = std::min(std::max(n, 0), hw::kMaxTracks);
  g_host->cur.tracks.resize(size_t(n));
  g_host->publish();
}

// notes is a flat list of [start, length, pitch, velocity 1..127] per note, in ticks.
JF(void, nativeSetTrack, jint index, jint kind, jint preset, jfloat vol, jfloat pan, jboolean mute, jboolean solo,
   jint lenTicks, jintArray notes) {
  H();
  if (index < 0 || index >= hw::kMaxTracks) return;
  auto& tracks = g_host->cur.tracks;
  if (size_t(index) >= tracks.size()) tracks.resize(size_t(index) + 1);
  hw::Track& t = tracks[size_t(index)];
  t.kind = kind == 1 ? hw::InstrumentKind::Drums : hw::InstrumentKind::Synth;
  t.synth = makePreset(preset);
  t.volume = vol;
  t.pan = pan;
  t.mute = mute == JNI_TRUE;
  t.solo = solo == JNI_TRUE;
  hw::MidiClip c;
  c.start = 0;
  c.length = std::max(lenTicks, 1);
  if (notes) {
    jsize len = env->GetArrayLength(notes);
    std::vector<jint> buf(static_cast<size_t>(len), 0);
    if (len > 0) env->GetIntArrayRegion(notes, 0, len, buf.data());
    for (jsize i = 0; i + 3 < len; i += 4) {
      hw::Note n;
      n.start = buf[size_t(i)];
      n.length = std::max(buf[size_t(i) + 1], 1);
      n.pitch = uint8_t(std::min(std::max(buf[size_t(i) + 2], 0), 127));
      n.velocity = float(std::min(std::max(buf[size_t(i) + 3], 1), 127)) / 127.f;
      c.notes.push_back(n);
    }
  }
  c.sortNotes();
  t.clips.clear();
  t.clips.push_back(std::move(c));
  g_host->publish();
}

JF(void, nativeSetTempo, jfloat bpm) {
  (void)env;
  H();
  hw::Tick keep = g_host->engine.positionTicks();
  g_host->cur.tempo.setTempos({{0, double(bpm)}});
  g_host->publish();
  g_host->engine.seekTicks(keep);
}

JF(void, nativeSetLoop, jboolean on, jint bars) {
  (void)env;
  H();
  if (on == JNI_TRUE) g_host->engine.setLoop(true, 0, hw::Tick(std::max(bars, 1)) * kBar);
  else g_host->engine.setLoop(false, 0, 0);
}

JF(void, nativeSetMetronome, jboolean on) {
  (void)env;
  H();
  g_host->cur.metronome = on == JNI_TRUE;
  g_host->publish();
}

JF(void, nativeSetMaster, jfloat g) {
  (void)env;
  H();
  g_host->cur.masterGain = g;
  g_host->publish();
}

JF(void, nativePlay) { (void)env; H()->engine.play(); }
JF(void, nativePause) { (void)env; H()->engine.stop(); }
JF(void, nativeSeekBeats, jdouble beats) {
  (void)env;
  H()->engine.seekTicks(hw::Tick(std::max(beats, 0.0) * hw::kPpq));
}
JF(jboolean, nativeIsPlaying) { (void)env; return g_host && g_host->engine.playing() ? JNI_TRUE : JNI_FALSE; }
JF(jdouble, nativePositionBeats) {
  (void)env;
  return g_host ? double(g_host->engine.positionTicks()) / hw::kPpq : 0.0;
}
JF(jfloat, nativeMasterPeak) { (void)env; return g_host ? g_host->engine.masterPeak() : 0.f; }
JF(jfloat, nativeTrackPeak, jint i) { (void)env; return g_host ? g_host->engine.trackPeak(i) : 0.f; }
JF(jfloat, nativeDspLoad) { (void)env; return g_host ? g_host->load.load() : 0.f; }
JF(jint, nativeXruns) {
  (void)env;
  if (!g_host || !g_host->stream) return 0;
  auto r = g_host->stream->getXRunCount();
  return r.error() == oboe::Result::OK ? r.value() : 0;
}
JF(jfloat, nativeLatencyMs) {
  (void)env;
  if (!g_host || !g_host->stream) return 0.f;
  auto r = g_host->stream->calculateLatencyMillis();
  return r.error() == oboe::Result::OK ? float(r.value()) : 0.f;
}
