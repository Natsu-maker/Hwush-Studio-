#include <cmath>
#include <cstdio>
#include <memory>
#include "hw/engine.h"
#include "hw/offline.h"
#include "hw/wav.h"
#include "../tools/song.h"

using namespace hw;
static int failures = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { failures++; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)

static Snapshot oneNote(int tick, int len, int pitch = 69) {
  Snapshot s;
  Track t; MidiClip c; c.length = kPpq * 64;
  Note n; n.start = tick; n.length = len; n.pitch = uint8_t(pitch); n.velocity = 1.f;
  c.notes.push_back(n);
  t.clips.push_back(c);
  s.tracks.push_back(t);
  return s;
}

static double rms(const std::vector<float>& v, size_t a, size_t b) {  // frames a..b of stereo data
  double e = 0; for (size_t i = a * 2; i < b * 2 && i < v.size(); i++) e += double(v[i]) * v[i];
  return std::sqrt(e / double((b - a) * 2));
}

static void testTempo() {
  TempoMap m;
  CHECK(std::fabs(m.ticksToSeconds(kPpq) - 0.5) < 1e-12);
  CHECK(m.ticksToFrames(kPpq, 48000) == 24000);
  m.setTempos({{0, 120.0}, {kPpq * 4, 60.0}});
  CHECK(std::fabs(m.ticksToSeconds(kPpq * 4) - 2.0) < 1e-12);
  CHECK(std::fabs(m.ticksToSeconds(kPpq * 5) - 3.0) < 1e-12);
  CHECK(std::fabs(m.secondsToTicks(3.0) - kPpq * 5) < 1e-6);
  for (Tick t : {0, 1, 959, 960, 3839, 3840, 3841, 10000}) {
    Frame f = m.ticksToFrames(t, 44100);
    CHECK(m.framesToTicks(f, 44100) >= t - 1 && m.framesToTicks(f, 44100) <= t + 1);
  }
  CHECK(m.bpmAt(100) == 120.0 && m.bpmAt(kPpq * 4) == 60.0);
}

static void testSilence() {
  Snapshot s; s.tracks.push_back(Track());
  auto o = renderOffline(s, 48000, 1.0, 333);
  bool zero = true; for (float x : o) if (x != 0.f) zero = false;
  CHECK(zero);
}

static void testSampleAccurate() {
  Snapshot s = oneNote(kPpq, kPpq);          // starts at 0.5 s
  for (int block : {64, 777, 4096}) {
    auto o = renderOffline(s, 48000, 1.0, block);
    size_t first = 0; while (first < o.size() / 2 && o[first * 2] == 0.f && o[first * 2 + 1] == 0.f) first++;
    CHECK(first >= 24000 && first <= 24001);
  }
}

static void testBlockInvariance() {
  Snapshot s = demoSong();
  s.metronome = true;
  auto ref = renderOffline(s, 44100, 6.0, 512);
  for (int b : {1, 64, 127, 1024, 4096, 20000}) {
    auto o = renderOffline(s, 44100, 6.0, b);
    double worst = 0; for (size_t i = 0; i < ref.size(); i++) worst = std::max(worst, double(std::fabs(ref[i] - o[i])));
    std::printf("  block %5d max diff %.3g\n", b, worst);
    CHECK(worst < 1e-6);
  }
}

static void testFinite() {
  Snapshot s = demoSong();
  for (auto& t : s.tracks) t.volume = 4.f;
  s.masterGain = 4.f;
  auto o = renderOffline(s, 48000, 10.0, 512);
  bool ok = true; float pk = 0;
  for (float x : o) { if (!std::isfinite(x)) ok = false; pk = std::max(pk, std::fabs(x)); }
  CHECK(ok);
  CHECK(pk <= 1.0001f);
}

static void testLoop() {
  Snapshot s = oneNote(0, kPpq);
  Engine e(48000);
  e.publish(std::make_shared<const Snapshot>(s));
  e.setLoop(true, 0, kPpq * 4);   // 2 seconds
  e.play();
  std::vector<float> o(48000 * 6 * 2);
  for (size_t d = 0; d < 48000 * 6; d += 1000) e.render(o.data() + d * 2, int(std::min<size_t>(1000, 48000 * 6 - d)));
  double a = rms(o, 0, 2400), b = rms(o, 96000, 98400), c = rms(o, 192000, 194400);
  CHECK(a > 0.01);
  CHECK(std::fabs(b - a) < a * 0.1);
  CHECK(std::fabs(c - a) < a * 0.1);
  CHECK(e.positionFrames() < 96000);
}

static void testMuteSolo() {
  Snapshot s = demoSong();
  Snapshot only = s; only.tracks = {s.tracks[1]};
  Snapshot muted = s; for (size_t i = 0; i < muted.tracks.size(); i++) muted.tracks[i].mute = (i != 1);
  Snapshot solo = s; solo.tracks[1].solo = true;
  auto a = renderOffline(only, 44100, 4.0, 512), b = renderOffline(muted, 44100, 4.0, 512), c = renderOffline(solo, 44100, 4.0, 512);
  double d1 = 0, d2 = 0;
  for (size_t i = 0; i < a.size(); i++) { d1 = std::max(d1, double(std::fabs(a[i] - b[i]))); d2 = std::max(d2, double(std::fabs(a[i] - c[i]))); }
  CHECK(d1 < 1e-6);
  CHECK(d2 < 1e-6);
}

static void testLive() {
  Snapshot s; s.tracks.push_back(Track());
  Engine e(48000);
  e.publish(std::make_shared<const Snapshot>(s));
  std::vector<float> o(48000 * 2);
  e.render(o.data(), 512);
  e.liveNoteOn(0, 60, 1.f);
  e.render(o.data(), 4800);
  CHECK(rms(o, 1000, 4800) > 0.01);
  e.liveNoteOff(0, 60);
  for (int i = 0; i < 6; i++) e.render(o.data(), 48000 / 2);
  CHECK(rms(o, 0, 1000) < 1e-3);
}

static void testSnapshots() {
  Engine e(48000);
  for (int i = 0; i < 6; i++) e.publish(std::make_shared<const Snapshot>(demoSong()));
  CHECK(e.retiredPending() == 0);
  std::vector<float> o(1024);
  e.render(o.data(), 512);
  CHECK(e.retiredPending() == 0);
}

static void testDrums() {
  Snapshot s;
  Track t; t.kind = InstrumentKind::Drums; MidiClip c; c.length = kPpq * 8;
  Note k; k.start = 0; k.length = 120; k.pitch = 36; k.velocity = 1.f; c.notes.push_back(k);
  t.clips.push_back(c); s.tracks.push_back(t);
  auto o = renderOffline(s, 44100, 1.0, 256);
  float pk = 0; for (float x : o) pk = std::max(pk, std::fabs(x));
  CHECK(pk > 0.3f);
  CHECK(rms(o, 40000, 44100) < 1e-4);
  // open hat is cut by a closed hat
  Snapshot h = s; h.tracks[0].clips[0].notes.clear();
  Note oh; oh.start = 0; oh.length = 120; oh.pitch = 46; oh.velocity = 1.f;
  h.tracks[0].clips[0].notes.push_back(oh);
  auto open = renderOffline(h, 44100, 0.6, 256);
  Note ch; ch.start = 480; ch.length = 120; ch.pitch = 42; ch.velocity = 0.01f;
  h.tracks[0].clips[0].notes.push_back(ch);
  auto cut = renderOffline(h, 44100, 0.6, 256);
  CHECK(rms(cut, 20000, 26000) < rms(open, 20000, 26000) * 0.2);
}

static void testWav() {
  std::vector<float> d; for (int i = 0; i < 2000; i++) d.push_back(0.8f * std::sin(float(i) * 0.05f));
  for (int bits : {16, 24, 32}) {
    const char* p = "/tmp/hw_test.wav";
    CHECK(writeWav(p, d, 44100, bits));
    std::vector<float> r; int sr = 0, ch = 0;
    CHECK(readWav(p, r, sr, ch));
    CHECK(sr == 44100 && ch == 2 && r.size() == d.size());
    double worst = 0; for (size_t i = 0; i < d.size() && i < r.size(); i++) worst = std::max(worst, double(std::fabs(d[i] - r[i])));
    CHECK(worst < (bits == 16 ? 1.0 / 16000 : 1e-6));
  }
}

int main() {
  testTempo(); testSilence(); testSampleAccurate(); testBlockInvariance(); testFinite();
  testLoop(); testMuteSolo(); testLive(); testSnapshots(); testDrums(); testWav();
  std::printf("%d checks, %d failed\n", checks, failures);
  return failures ? 1 : 0;
}
