#pragma once
#include <array>
#include <atomic>
#include <memory>
#include <mutex>
#include <vector>
#include "hw/instruments.h"
#include "hw/project.h"

namespace hw {

/// The audio engine. render() is the only call that runs on the audio thread. Everything else is for the control side.
class Engine {
 public:
  explicit Engine(double sampleRate);

  // ---- control side ----
  void publish(std::shared_ptr<const Snapshot> s);
  void play();
  void stop();
  bool playing() const { return playing_.load(); }
  void seekTicks(Tick t);
  Frame positionFrames() const;
  Tick positionTicks() const;
  void setLoop(bool on, Tick startTick, Tick endTick);
  void liveNoteOn(int track, int pitch, float vel);
  void liveNoteOff(int track, int pitch);
  float trackPeak(int t) const { return t >= 0 && t < kMaxTracks ? trackPk_[size_t(t)].load() : 0.f; }
  float masterPeak() const { return masterPk_.load(); }
  size_t retiredPending();  // snapshots waiting to be freed; 0 when only the live one is held
  double sampleRate() const { return sr_; }

  // ---- audio thread ----
  void render(float* out, int frames);  // interleaved stereo

 private:
  struct Ev { int off; int kind; int track; uint8_t pitch; float vel; Frame offFrame; bool down; };  // kind 0 note, 1 click, 2 live note off
  struct Live { int track; uint8_t pitch; float vel; bool on; };
  struct TrackRt {
    TrackRt(double sr) : synth(sr), drums(sr) {}
    SynthInstr synth;
    DrumInstr drums;
    float gL = 0, gR = 0, tL = 0, tR = 0;
    bool init = false, active = false;
    InstrumentKind kind = InstrumentKind::Synth;
  };
  struct Click { int remain = 0, total = 1; float ph = 0, inc = 0, amp = 0; };

  const Snapshot* acquire();
  int renderChunk(float* out, int maxN);
  void collect(const Snapshot& s, Frame pos, int n);
  void apply(const Snapshot& s, const Ev& e);
  void segment(const Snapshot& s, int from, int len, Frame segPos);
  void allNotesOff(const Snapshot& s);
  void pushEv(const Ev& e) { if (events_.size() < events_.capacity()) events_.push_back(e); }

  double sr_;
  float smoothCoef_;
  std::mutex mu_;
  std::vector<std::shared_ptr<const Snapshot>> owned_;
  std::shared_ptr<const Snapshot> latest_;
  std::atomic<const Snapshot*> pending_{nullptr};
  std::atomic<const Snapshot*> inUse_{nullptr};

  std::atomic<bool> playing_{false};
  std::atomic<Frame> pos_{0};
  std::atomic<Frame> seekReq_{-1};
  std::atomic<bool> loopOn_{false};
  std::atomic<Tick> loopStart_{0}, loopEnd_{0};

  std::array<Live, 256> ring_{};
  std::atomic<uint32_t> head_{0}, tail_{0};

  std::vector<std::unique_ptr<TrackRt>> tr_;
  std::vector<float> mixL_, mixR_, mono_;
  std::vector<Ev> events_;
  Click click_;
  float masterG_ = 1.f;
  bool masterInit_ = false;
  bool wasPlaying_ = false;
  std::array<std::atomic<float>, kMaxTracks> trackPk_;
  std::atomic<float> masterPk_{0.f};
  std::array<float, kMaxTracks> localPk_{};
};

}  // namespace hw
