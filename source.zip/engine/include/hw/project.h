#pragma once
#include <string>
#include <vector>
#include "hw/tempo_map.h"
#include "hw/types.h"

namespace hw {

enum class InstrumentKind : uint8_t { Synth, Drums };
enum class Wave : uint8_t { Sine, Saw, Square, Triangle };
enum class FilterType : uint8_t { LowPass, HighPass, BandPass };

struct SynthParams {
  Wave osc1 = Wave::Saw;
  Wave osc2 = Wave::Saw;
  float osc2Detune = 7.f;     // cents
  int osc2Semis = 0;
  float osc2Level = 0.5f;
  float subLevel = 0.f;       // a sine an octave down
  float pulseWidth = 0.5f;    // for the square wave
  FilterType filter = FilterType::LowPass;
  float cutoff = 8000.f;      // Hz
  float resonance = 0.2f;     // 0 to 1
  float filterEnvAmt = 0.f;   // octaves the filter envelope can open
  float ampA = 0.005f, ampD = 0.2f, ampS = 0.7f, ampR = 0.25f;
  float fltA = 0.005f, fltD = 0.3f, fltS = 0.3f, fltR = 0.3f;
  float gain = 0.5f;
  int voices = 8;             // polyphony, up to 16
};

struct Note {
  Tick start = 0;     // relative to the clip start
  Tick length = 0;
  uint8_t pitch = 60;
  float velocity = 0.8f;  // 0 to 1
};

struct MidiClip {
  Tick start = 0;
  Tick length = 0;
  std::vector<Note> notes;  // must be sorted by start; call sortNotes() after editing
  void sortNotes();
};

struct Track {
  std::string name;
  InstrumentKind kind = InstrumentKind::Synth;
  SynthParams synth;
  float volume = 1.f;  // linear
  float pan = 0.f;     // -1 left, +1 right
  bool mute = false;
  bool solo = false;
  std::vector<MidiClip> clips;
};

/// Everything the audio thread needs to play a project. It is built on the control side and handed over whole,
/// so the audio thread never sees a half edited project.
struct Snapshot {
  TempoMap tempo;
  std::vector<Track> tracks;
  float masterGain = 1.f;
  bool metronome = false;
};

}  // namespace hw
