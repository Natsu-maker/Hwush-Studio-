#pragma once
#include <string>
#include <vector>

namespace hw {
/// Writes interleaved stereo floats as a WAV file. bits: 16, 24, or 32 (float).
bool writeWav(const std::string& path, const std::vector<float>& stereo, int sampleRate, int bits);
/// Reads 16/24-bit PCM or 32-bit float WAV into interleaved floats.
bool readWav(const std::string& path, std::vector<float>& out, int& sampleRate, int& channels);
}  // namespace hw
