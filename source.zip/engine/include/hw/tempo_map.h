#pragma once
#include <vector>
#include "hw/types.h"

namespace hw {

struct TempoPoint { Tick tick; double bpm; };
struct TimeSigPoint { Tick tick; int num; int den; };

/// Turns musical time (ticks) into real time and back. Tempo is constant between points.
class TempoMap {
 public:
  TempoMap();
  void setTempos(std::vector<TempoPoint> pts);          // the first point is forced to tick 0
  void setTimeSigs(std::vector<TimeSigPoint> pts);

  double ticksToSeconds(Tick t) const;
  double secondsToTicks(double s) const;                // fractional ticks
  Frame ticksToFrames(Tick t, double sampleRate) const; // nearest frame
  Tick framesToTicks(Frame f, double sampleRate) const; // rounds down
  double bpmAt(Tick t) const;
  int beatsPerBar(Tick t) const;

  const std::vector<TempoPoint>& tempos() const { return tempos_; }
  const std::vector<TimeSigPoint>& timeSigs() const { return sigs_; }

 private:
  void rebuild();
  std::vector<TempoPoint> tempos_;
  std::vector<double> secAt_;   // seconds at each tempo point
  std::vector<TimeSigPoint> sigs_;
};

}  // namespace hw
