#pragma once
#include <vector>
#include "hw/project.h"

namespace hw {
/// Plays a project from the start and returns interleaved stereo floats. `block` is the buffer size used for rendering.
std::vector<float> renderOffline(const Snapshot& s, double sampleRate, double seconds, int block = 512);
}  // namespace hw
