#pragma once
#include <cstdint>
#include "hw/dsp.h"
#include "hw/project.h"

namespace hw {

/// All instruments render mono, adding into `out`. offFrame is an absolute timeline frame (or -1 = held until noteOff).
class SynthInstr {
 public:
  explicit SynthInstr(double sr) : sr_(float(sr)) {}
  void noteOn(uint8_t pitch, float vel, Frame offFrame, const SynthParams& p);
  void noteOff(uint8_t pitch);
  void allNotesOff();
  void reset();
  void render(float* out, int n, Frame base, const SynthParams& p);
  int activeVoices() const;

 private:
  struct Voice {
    bool active = false, released = false;
    uint8_t pitch = 0;
    float vel = 0, freq = 0;
    uint64_t serial = 0;
    Frame offFrame = -1;
    float ph1 = 0, ph2 = 0, phSub = 0;
    uint32_t count = 0;
    Adsr amp, flt;
    Svf svf;
  };
  static float osc(Wave w, float ph, float dt, float pw);
  float sr_;
  Voice v_[16];
  uint64_t serial_ = 0;
};

class DrumInstr {
 public:
  explicit DrumInstr(double sr) : sr_(float(sr)) {}
  void noteOn(uint8_t pitch, float vel);
  void reset();
  void render(float* out, int n);
  int activeVoices() const;

 private:
  enum Kind : uint8_t { Kick, Snare, Clap, HatC, HatO, Tom, Rim, Crash };
  struct Voice {
    bool active = false, choked = false;
    Kind kind = Kick;
    float vel = 1, base = 100, ph = 0, lp = 0, lp2 = 0;
    float t = 0, len = 0.5f;
    Rng rng;
  };
  float sr_;
  Voice v_[16];
  uint32_t seed_ = 12345;
};

}  // namespace hw
