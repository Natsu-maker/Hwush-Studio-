#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include "hw/types.h"

namespace hw {

inline float midiToFreq(float note) { return 440.f * std::exp2((note - 69.f) / 12.f); }

struct Rng {
  uint32_t s = 2463534242u;
  explicit Rng(uint32_t seed = 2463534242u) : s(seed ? seed : 1u) {}
  uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
  float uni() { return float(next() >> 8) * (1.f / 8388608.f) - 1.f; }  // -1..1
};

// Band-limited step correction for saw and square edges. t is the phase 0..1, dt the phase step.
inline float polyBlep(float t, float dt) {
  if (t < dt) { t /= dt; return t + t - t * t - 1.f; }
  if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
  return 0.f;
}

inline float softClip(float x) {
  float a = std::fabs(x);
  if (a <= 0.9f) return x;
  float y = 0.9f + 0.1f * std::tanh((a - 0.9f) / 0.1f);
  return x < 0 ? -y : y;
}

/// Zero delay feedback state variable filter.
struct Svf {
  float ic1 = 0, ic2 = 0;
  float a1 = 0, a2 = 0, a3 = 0, k = 1;
  void set(float fc, float res, float sr) {
    fc = std::min(std::max(fc, 20.f), 0.45f * sr);
    float g = std::tan(float(kPi) * fc / sr);
    k = 2.f - 1.96f * std::min(std::max(res, 0.f), 1.f);
    a1 = 1.f / (1.f + g * (g + k));
    a2 = g * a1;
    a3 = g * a2;
  }
  // mode 0 low, 1 high, 2 band
  float tick(float x, int mode) {
    float v3 = x - ic2;
    float v1 = a1 * ic1 + a2 * v3;
    float v2 = ic2 + a2 * ic1 + a3 * v3;
    ic1 = 2.f * v1 - ic1;
    ic2 = 2.f * v2 - ic2;
    if (mode == 0) return v2;
    if (mode == 1) return x - k * v1 - v2;
    return v1;
  }
};

struct Adsr {
  enum St { Idle, Att, Dec, Sus, Rel };
  St st = Idle;
  float level = 0, aInc = 0.01f, dCoef = 0.999f, sus = 0.7f, rCoef = 0.999f;
  void set(float a, float d, float s, float r, float sr) {
    aInc = 1.f / (std::max(a, 0.001f) * sr);
    dCoef = std::exp(-1.f / (std::max(d, 0.001f) / 4.f * sr));
    rCoef = std::exp(-1.f / (std::max(r, 0.001f) / 4.f * sr));
    sus = std::min(std::max(s, 0.f), 1.f);
  }
  void gate() { st = Att; level = 0; }
  void release() { if (st != Idle) st = Rel; }
  float tick() {
    switch (st) {
      case Idle: return 0.f;
      case Att: level += aInc; if (level >= 1.f) { level = 1.f; st = Dec; } break;
      case Dec:
        level = sus + (level - sus) * dCoef;
        if (level - sus < 1e-4f) { level = sus; st = Sus; if (sus <= 1e-4f) { st = Idle; level = 0; } }
        break;
      case Sus: break;
      case Rel: level *= rCoef; if (level < 1e-4f) { level = 0; st = Idle; } break;
    }
    return level;
  }
};

}  // namespace hw
