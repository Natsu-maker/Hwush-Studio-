#pragma once
#include <cstdint>
#include <cmath>

namespace hw {

constexpr int kPpq = 960;        // ticks per quarter note
constexpr int kMaxTracks = 64;
constexpr int kMaxBlock = 8192;  // the most frames the engine renders in one go
using Tick = int64_t;
using Frame = int64_t;
constexpr double kPi = 3.14159265358979323846;

}  // namespace hw
