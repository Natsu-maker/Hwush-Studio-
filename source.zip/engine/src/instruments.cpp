#include "hw/instruments.h"
#include <cstring>

namespace hw {

// ---------------- Synth ----------------
float SynthInstr::osc(Wave w, float ph, float dt, float pw) {
  switch (w) {
    case Wave::Sine: return std::sin(2.f * float(kPi) * ph);
    case Wave::Saw: return 2.f * ph - 1.f - polyBlep(ph, dt);
    case Wave::Square: {
      float v = ph < pw ? 1.f : -1.f;
      v += polyBlep(ph, dt);
      float t2 = ph - pw; if (t2 < 0) t2 += 1.f;
      v -= polyBlep(t2, dt);
      return v;
    }
    case Wave::Triangle: return 4.f * std::fabs(ph - 0.5f) - 1.f;
  }
  return 0.f;
}

void SynthInstr::noteOn(uint8_t pitch, float vel, Frame offFrame, const SynthParams& p) {
  int maxV = std::min(std::max(p.voices, 1), 16);
  Voice* pick = nullptr;
  for (int i = 0; i < maxV; i++) if (!v_[i].active) { pick = &v_[i]; break; }
  if (!pick) {
    for (int i = 0; i < maxV; i++)
      if (v_[i].released && (!pick || v_[i].serial < pick->serial)) pick = &v_[i];
    if (!pick) for (int i = 0; i < maxV; i++) if (!pick || v_[i].serial < pick->serial) pick = &v_[i];
  }
  Voice& v = *pick;
  v = Voice();
  v.active = true;
  v.pitch = pitch;
  v.vel = std::min(std::max(vel, 0.f), 1.f);
  v.freq = midiToFreq(float(pitch));
  v.serial = ++serial_;
  v.offFrame = offFrame;
  v.amp.set(p.ampA, p.ampD, p.ampS, p.ampR, sr_);
  v.flt.set(p.fltA, p.fltD, p.fltS, p.fltR, sr_);
  v.amp.gate();
  v.flt.gate();
}

void SynthInstr::noteOff(uint8_t pitch) {
  for (auto& v : v_)
    if (v.active && !v.released && v.pitch == pitch && v.offFrame < 0) { v.released = true; v.amp.release(); v.flt.release(); }
}

void SynthInstr::allNotesOff() {
  for (auto& v : v_) if (v.active && !v.released) { v.released = true; v.amp.release(); v.flt.release(); }
}

void SynthInstr::reset() { for (auto& v : v_) v = Voice(); }

int SynthInstr::activeVoices() const { int c = 0; for (auto& v : v_) c += v.active; return c; }

void SynthInstr::render(float* out, int n, Frame base, const SynthParams& p) {
  const float ratio2 = std::exp2((float(p.osc2Semis) * 100.f + p.osc2Detune) / 1200.f);
  const float norm = 1.f / (1.f + p.osc2Level + p.subLevel);
  const int mode = p.filter == FilterType::LowPass ? 0 : p.filter == FilterType::HighPass ? 1 : 2;
  const float pw = std::min(std::max(p.pulseWidth, 0.05f), 0.95f);
  for (auto& v : v_) {
    if (!v.active) continue;
    const float dt1 = v.freq / sr_, dt2 = v.freq * ratio2 / sr_, dtS = v.freq * 0.5f / sr_;
    for (int i = 0; i < n; i++) {
      if (!v.released && v.offFrame >= 0 && base + i >= v.offFrame) { v.released = true; v.amp.release(); v.flt.release(); }
      float fe = v.flt.tick();
      if ((v.count & 15u) == 0) {
        float fc = p.cutoff * std::exp2(p.filterEnvAmt * fe);
        v.svf.set(fc, p.resonance, sr_);
      }
      float ae = v.amp.tick();
      if (v.amp.st == Adsr::Idle) { v.active = false; break; }
      float s = osc(p.osc1, v.ph1, dt1, pw);
      if (p.osc2Level > 0.f) s += p.osc2Level * osc(p.osc2, v.ph2, dt2, pw);
      if (p.subLevel > 0.f) s += p.subLevel * std::sin(2.f * float(kPi) * v.phSub);
      s *= norm;
      s = v.svf.tick(s, mode);
      out[i] += s * ae * v.vel * p.gain;
      v.ph1 += dt1; if (v.ph1 >= 1.f) v.ph1 -= 1.f;
      v.ph2 += dt2; if (v.ph2 >= 1.f) v.ph2 -= 1.f;
      v.phSub += dtS; if (v.phSub >= 1.f) v.phSub -= 1.f;
      v.count++;
    }
  }
}

// ---------------- Drums ----------------
void DrumInstr::reset() { for (auto& v : v_) v = Voice(); }
int DrumInstr::activeVoices() const { int c = 0; for (auto& v : v_) c += v.active; return c; }

void DrumInstr::noteOn(uint8_t pitch, float vel) {
  Kind k; float base = 100, len = 0.4f;
  switch (pitch) {
    case 35: case 36: k = Kick; len = 0.5f; break;
    case 37: k = Rim; len = 0.08f; break;
    case 38: case 40: k = Snare; len = 0.35f; break;
    case 39: k = Clap; len = 0.4f; break;
    case 42: case 44: k = HatC; len = 0.12f; break;
    case 46: k = HatO; len = 0.6f; break;
    case 41: k = Tom; base = 80; len = 0.5f; break;
    case 43: k = Tom; base = 100; len = 0.45f; break;
    case 45: k = Tom; base = 125; len = 0.4f; break;
    case 47: k = Tom; base = 150; len = 0.4f; break;
    case 48: case 50: k = Tom; base = 185; len = 0.35f; break;
    case 49: case 51: case 52: case 55: case 57: k = Crash; len = 2.0f; break;
    default: return;
  }
  if (k == HatC) for (auto& o : v_) if (o.active && o.kind == HatO) o.choked = true;
  Voice* pick = nullptr;
  for (auto& o : v_) if (!o.active) { pick = &o; break; }
  if (!pick) { pick = &v_[0]; for (auto& o : v_) if (o.t > pick->t) pick = &o; }
  Voice& v = *pick;
  v = Voice();
  v.active = true; v.kind = k; v.base = base; v.len = len;
  v.vel = std::min(std::max(vel, 0.f), 1.f);
  v.rng = Rng(seed_ = seed_ * 1664525u + 1013904223u);
}

void DrumInstr::render(float* out, int n) {
  const float dt = 1.f / sr_;
  for (auto& v : v_) {
    if (!v.active) continue;
    for (int i = 0; i < n; i++) {
      float t = v.t, s = 0.f;
      switch (v.kind) {
        case Kick: {
          float f = 48.f + 110.f * std::exp(-t / 0.028f);
          v.ph += f * dt; if (v.ph >= 1.f) v.ph -= 1.f;
          s = std::sin(2.f * float(kPi) * v.ph) * std::exp(-t / 0.18f);
          s += 0.25f * v.rng.uni() * std::exp(-t / 0.003f);
          s *= std::min(1.f, t / 0.0008f);
          break;
        }
        case Snare: {
          v.ph += 185.f * dt; if (v.ph >= 1.f) v.ph -= 1.f;
          float tone = std::sin(2.f * float(kPi) * v.ph) * std::exp(-t / 0.07f) * 0.5f;
          float nz = v.rng.uni();
          v.lp += 0.25f * (nz - v.lp);
          float hp = nz - v.lp;
          s = tone + hp * std::exp(-t / 0.11f) * 0.7f;
          break;
        }
        case Clap: {
          float nz = v.rng.uni();
          v.lp += 0.2f * (nz - v.lp);
          float hp = nz - v.lp;
          float burst = 0.f;
          for (int b = 0; b < 3; b++) { float tb = t - 0.011f * b; if (tb >= 0 && tb < 0.009f) burst = 1.f; }
          float tail = t >= 0.033f ? std::exp(-(t - 0.033f) / 0.09f) : 0.f;
          s = hp * (burst * 0.9f + tail) * 0.9f;
          break;
        }
        case HatC: case HatO: case Crash: {
          float nz = v.rng.uni();
          v.lp += 0.55f * (nz - v.lp);
          float hp = nz - v.lp;
          float tc = v.kind == HatC ? 0.03f : v.kind == HatO ? 0.2f : 0.7f;
          float a = std::exp(-t / tc);
          if (v.choked) { v.lp2 += dt / 0.004f; a *= std::max(0.f, 1.f - v.lp2); if (v.lp2 >= 1.f) v.active = false; }
          s = hp * a * (v.kind == Crash ? 0.5f : 0.45f);
          break;
        }
        case Tom: {
          float f = v.base * (1.f + 0.6f * std::exp(-t / 0.04f));
          v.ph += f * dt; if (v.ph >= 1.f) v.ph -= 1.f;
          s = std::sin(2.f * float(kPi) * v.ph) * std::exp(-t / 0.16f) * 0.9f;
          break;
        }
        case Rim: {
          v.ph += 820.f * dt; if (v.ph >= 1.f) v.ph -= 1.f;
          s = (std::sin(2.f * float(kPi) * v.ph) * 0.6f + v.rng.uni() * 0.3f) * std::exp(-t / 0.012f);
          break;
        }
      }
      out[i] += s * v.vel * 0.55f;
      v.t += dt;
      if (v.t >= v.len) v.active = false;
      if (!v.active) break;
    }
  }
}

}  // namespace hw
