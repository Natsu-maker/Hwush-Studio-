#include "hw/wav.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>

namespace hw {

static void put16(std::ofstream& f, uint16_t v) { f.put(char(v & 255)); f.put(char(v >> 8)); }
static void put32(std::ofstream& f, uint32_t v) { for (int i = 0; i < 4; i++) f.put(char((v >> (8 * i)) & 255)); }

bool writeWav(const std::string& path, const std::vector<float>& d, int sr, int bits) {
  if (bits != 16 && bits != 24 && bits != 32) return false;
  std::ofstream f(path, std::ios::binary);
  if (!f) return false;
  const int bytes = bits / 8;
  const uint32_t dataSize = uint32_t(d.size()) * uint32_t(bytes);
  f.write("RIFF", 4); put32(f, 36 + dataSize); f.write("WAVE", 4);
  f.write("fmt ", 4); put32(f, 16);
  put16(f, bits == 32 ? 3 : 1); put16(f, 2); put32(f, uint32_t(sr));
  put32(f, uint32_t(sr * 2 * bytes)); put16(f, uint16_t(2 * bytes)); put16(f, uint16_t(bits));
  f.write("data", 4); put32(f, dataSize);
  for (float x : d) {
    x = std::min(std::max(x, -1.f), 1.f);
    if (bits == 16) { int v = int(std::lround(x * 32767.f)); put16(f, uint16_t(int16_t(v))); }
    else if (bits == 24) { int v = int(std::lround(x * 8388607.f)); f.put(char(v & 255)); f.put(char((v >> 8) & 255)); f.put(char((v >> 16) & 255)); }
    else { uint32_t u; std::memcpy(&u, &x, 4); put32(f, u); }
  }
  return bool(f);
}

bool readWav(const std::string& path, std::vector<float>& out, int& sr, int& ch) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return false;
  char id[4]; uint32_t sz;
  auto r32 = [&]() { uint8_t b[4]; f.read(reinterpret_cast<char*>(b), 4); return uint32_t(b[0]) | uint32_t(b[1]) << 8 | uint32_t(b[2]) << 16 | uint32_t(b[3]) << 24; };
  auto r16 = [&]() { uint8_t b[2]; f.read(reinterpret_cast<char*>(b), 2); return uint16_t(b[0] | b[1] << 8); };
  f.read(id, 4); if (std::memcmp(id, "RIFF", 4)) return false;
  r32(); f.read(id, 4); if (std::memcmp(id, "WAVE", 4)) return false;
  int fmt = 0, bits = 0; sr = 0; ch = 0;
  while (f.read(id, 4)) {
    sz = r32();
    if (!std::memcmp(id, "fmt ", 4)) {
      fmt = r16(); ch = r16(); sr = int(r32()); r32(); r16(); bits = r16();
      if (sz > 16) f.ignore(sz - 16);
    } else if (!std::memcmp(id, "data", 4)) {
      int bytes = bits / 8;
      if (bytes == 0 || ch == 0) return false;
      size_t count = sz / size_t(bytes);
      out.resize(count);
      for (size_t i = 0; i < count; i++) {
        if (bits == 16) out[i] = float(int16_t(r16())) / 32768.f;
        else if (bits == 24) { uint8_t b[3]; f.read(reinterpret_cast<char*>(b), 3); int v = b[0] | b[1] << 8 | b[2] << 16; if (v & 0x800000) v -= 0x1000000; out[i] = float(v) / 8388608.f; }
        else if (bits == 32 && fmt == 3) { uint32_t u = r32(); float x; std::memcpy(&x, &u, 4); out[i] = x; }
        else return false;
      }
      return bool(f) || f.eof();
    } else f.ignore(sz + (sz & 1));
  }
  return false;
}

}  // namespace hw
