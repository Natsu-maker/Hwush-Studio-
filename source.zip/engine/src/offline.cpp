#include "hw/offline.h"
#include <memory>
#include "hw/engine.h"

namespace hw {
std::vector<float> renderOffline(const Snapshot& s, double sr, double seconds, int block) {
  Engine e(sr);
  e.publish(std::make_shared<const Snapshot>(s));
  e.play();
  size_t total = size_t(seconds * sr + 0.5);
  std::vector<float> out(total * 2);
  size_t done = 0;
  while (done < total) {
    int n = int(std::min<size_t>(size_t(block), total - done));
    e.render(out.data() + done * 2, n);
    done += size_t(n);
  }
  return out;
}
}  // namespace hw
