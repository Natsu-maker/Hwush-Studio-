#include "hw/tempo_map.h"
#include <algorithm>

namespace hw {

TempoMap::TempoMap() {
  tempos_ = {{0, 120.0}};
  sigs_ = {{0, 4, 4}};
  rebuild();
}

void TempoMap::setTempos(std::vector<TempoPoint> pts) {
  if (pts.empty()) pts.push_back({0, 120.0});
  std::sort(pts.begin(), pts.end(), [](const TempoPoint& a, const TempoPoint& b) { return a.tick < b.tick; });
  pts[0].tick = 0;
  for (auto& p : pts) p.bpm = std::min(999.0, std::max(10.0, p.bpm));
  tempos_ = std::move(pts);
  rebuild();
}

void TempoMap::setTimeSigs(std::vector<TimeSigPoint> pts) {
  if (pts.empty()) pts.push_back({0, 4, 4});
  std::sort(pts.begin(), pts.end(), [](const TimeSigPoint& a, const TimeSigPoint& b) { return a.tick < b.tick; });
  pts[0].tick = 0;
  sigs_ = std::move(pts);
}

void TempoMap::rebuild() {
  secAt_.assign(tempos_.size(), 0.0);
  for (size_t i = 1; i < tempos_.size(); i++) {
    double span = double(tempos_[i].tick - tempos_[i - 1].tick);
    secAt_[i] = secAt_[i - 1] + span * 60.0 / (tempos_[i - 1].bpm * kPpq);
  }
}

double TempoMap::ticksToSeconds(Tick t) const {
  size_t i = size_t(std::upper_bound(tempos_.begin(), tempos_.end(), t,
                                     [](Tick v, const TempoPoint& p) { return v < p.tick; }) - tempos_.begin());
  i = i == 0 ? 0 : i - 1;
  return secAt_[i] + double(t - tempos_[i].tick) * 60.0 / (tempos_[i].bpm * kPpq);
}

double TempoMap::secondsToTicks(double s) const {
  size_t i = size_t(std::upper_bound(secAt_.begin(), secAt_.end(), s) - secAt_.begin());
  i = i == 0 ? 0 : i - 1;
  return double(tempos_[i].tick) + (s - secAt_[i]) * tempos_[i].bpm * kPpq / 60.0;
}

Frame TempoMap::ticksToFrames(Tick t, double sr) const {
  return Frame(std::llround(ticksToSeconds(t) * sr));
}

Tick TempoMap::framesToTicks(Frame f, double sr) const {
  return Tick(std::floor(secondsToTicks(double(f) / sr)));
}

double TempoMap::bpmAt(Tick t) const {
  size_t i = size_t(std::upper_bound(tempos_.begin(), tempos_.end(), t,
                                     [](Tick v, const TempoPoint& p) { return v < p.tick; }) - tempos_.begin());
  i = i == 0 ? 0 : i - 1;
  return tempos_[i].bpm;
}

int TempoMap::beatsPerBar(Tick t) const {
  size_t i = size_t(std::upper_bound(sigs_.begin(), sigs_.end(), t,
                                     [](Tick v, const TimeSigPoint& p) { return v < p.tick; }) - sigs_.begin());
  i = i == 0 ? 0 : i - 1;
  return sigs_[i].num;
}

}  // namespace hw
