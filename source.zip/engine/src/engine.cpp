#include "hw/engine.h"
#include <algorithm>
#include <cstring>

namespace hw {

Engine::Engine(double sr) : sr_(sr) {
  smoothCoef_ = 1.f - std::exp(-1.f / (0.005f * float(sr)));
  for (int i = 0; i < kMaxTracks; i++) { tr_.push_back(std::make_unique<TrackRt>(sr)); trackPk_[size_t(i)].store(0.f); }
  mixL_.assign(kMaxBlock, 0.f);
  mixR_.assign(kMaxBlock, 0.f);
  mono_.assign(kMaxBlock, 0.f);
  events_.reserve(8192);
}

// ---------------- control side ----------------
void Engine::publish(std::shared_ptr<const Snapshot> s) {
  std::lock_guard<std::mutex> g(mu_);
  owned_.push_back(s);
  latest_ = s;
  pending_.store(s.get());
  const Snapshot* use = inUse_.load();
  for (size_t i = 0; i < owned_.size();) {
    if (owned_[i] != latest_ && owned_[i].get() != use) owned_.erase(owned_.begin() + long(i));
    else i++;
  }
}

size_t Engine::retiredPending() {
  std::lock_guard<std::mutex> g(mu_);
  const Snapshot* use = inUse_.load();
  for (size_t i = 0; i < owned_.size();) {
    if (owned_[i] != latest_ && owned_[i].get() != use) owned_.erase(owned_.begin() + long(i));
    else i++;
  }
  return owned_.size() > 0 ? owned_.size() - 1 : 0;
}

void Engine::play() { playing_.store(true); }
void Engine::stop() { playing_.store(false); }

void Engine::seekTicks(Tick t) {
  std::shared_ptr<const Snapshot> s;
  { std::lock_guard<std::mutex> g(mu_); s = latest_; }
  TempoMap def;
  Frame f = (s ? s->tempo : def).ticksToFrames(std::max<Tick>(t, 0), sr_);
  seekReq_.store(f);
}

Frame Engine::positionFrames() const {
  Frame r = seekReq_.load();
  return r >= 0 ? r : pos_.load();
}

Tick Engine::positionTicks() const {
  std::shared_ptr<const Snapshot> s;
  { auto* self = const_cast<Engine*>(this); std::lock_guard<std::mutex> g(self->mu_); s = latest_; }
  TempoMap def;
  return (s ? s->tempo : def).framesToTicks(positionFrames(), sr_);
}

void Engine::setLoop(bool on, Tick a, Tick b) {
  loopStart_.store(a);
  loopEnd_.store(b);
  loopOn_.store(on);
}

void Engine::liveNoteOn(int track, int pitch, float vel) {
  uint32_t h = head_.load(std::memory_order_relaxed);
  if (h - tail_.load(std::memory_order_acquire) >= ring_.size()) return;
  ring_[h % ring_.size()] = {track, uint8_t(pitch), vel, true};
  head_.store(h + 1, std::memory_order_release);
}

void Engine::liveNoteOff(int track, int pitch) {
  uint32_t h = head_.load(std::memory_order_relaxed);
  if (h - tail_.load(std::memory_order_acquire) >= ring_.size()) return;
  ring_[h % ring_.size()] = {track, uint8_t(pitch), 0.f, false};
  head_.store(h + 1, std::memory_order_release);
}

// ---------------- audio thread ----------------
const Snapshot* Engine::acquire() {
  const Snapshot* p;
  do {
    p = pending_.load();
    inUse_.store(p);
  } while (p != pending_.load());
  return p;
}

void Engine::allNotesOff(const Snapshot&) {
  for (auto& t : tr_) t->synth.allNotesOff();
}

void Engine::render(float* out, int frames) {
  int done = 0;
  while (done < frames) {
    int n = renderChunk(out + size_t(done) * 2, std::min(frames - done, kMaxBlock));
    done += n;
  }
}

void Engine::apply(const Snapshot& s, const Ev& e) {
  if (e.kind == 1) {
    click_.total = click_.remain = int(0.025 * sr_);
    click_.ph = 0;
    click_.inc = 2.f * float(kPi) * (e.down ? 1500.f : 1000.f) / float(sr_);
    click_.amp = e.down ? 0.5f : 0.35f;
    return;
  }
  if (e.track < 0 || size_t(e.track) >= s.tracks.size() || e.track >= kMaxTracks) return;
  const Track& tk = s.tracks[size_t(e.track)];
  TrackRt& rt = *tr_[size_t(e.track)];
  if (e.kind == 2) { if (tk.kind == InstrumentKind::Synth) rt.synth.noteOff(e.pitch); return; }
  if (tk.kind == InstrumentKind::Synth) rt.synth.noteOn(e.pitch, e.vel, e.offFrame, tk.synth);
  else rt.drums.noteOn(e.pitch, e.vel);
}

void Engine::collect(const Snapshot& s, Frame pos, int n) {
  Tick t0 = s.tempo.framesToTicks(pos, sr_);
  Tick t1 = s.tempo.framesToTicks(pos + n, sr_) + 2;
  size_t nt = std::min<size_t>(s.tracks.size(), kMaxTracks);
  for (size_t ti = 0; ti < nt; ti++) {
    for (const MidiClip& clip : s.tracks[ti].clips) {
      Tick lo = t0 - clip.start - 2, hi = t1 - clip.start;
      if (hi < 0 || lo > clip.length) continue;
      auto it = std::lower_bound(clip.notes.begin(), clip.notes.end(), lo,
                                 [](const Note& a, Tick v) { return a.start < v; });
      for (; it != clip.notes.end() && it->start <= hi; ++it) {
        if (it->start < 0 || it->start >= clip.length) continue;
        Tick ns = clip.start + it->start;
        Frame nf = s.tempo.ticksToFrames(ns, sr_);
        if (nf < pos || nf >= pos + n) continue;
        Tick len = std::min(it->length, clip.length - it->start);
        if (len < 1) len = 1;
        Frame of = s.tempo.ticksToFrames(ns + len, sr_);
        if (of <= nf) of = nf + 1;
        pushEv({int(nf - pos), 0, int(ti), it->pitch, it->velocity, of, false});
      }
    }
  }
  if (s.metronome) {
    for (Tick b = (t0 / kPpq) * kPpq; b <= t1; b += kPpq) {
      if (b < 0) continue;
      Frame nf = s.tempo.ticksToFrames(b, sr_);
      if (nf < pos || nf >= pos + n) continue;
      bool down = ((b / kPpq) % s.tempo.beatsPerBar(b)) == 0;
      pushEv({int(nf - pos), 1, -1, 0, 0.f, -1, down});
    }
  }
}

void Engine::segment(const Snapshot& s, int from, int len, Frame segPos) {
  if (len <= 0) return;
  size_t nt = std::min<size_t>(s.tracks.size(), kMaxTracks);
  float* ml = mixL_.data() + from;
  float* mr = mixR_.data() + from;
  for (size_t i = 0; i < nt; i++) {
    TrackRt& rt = *tr_[i];
    const Track& tk = s.tracks[i];
    std::fill(mono_.begin(), mono_.begin() + len, 0.f);
    if (tk.kind == InstrumentKind::Synth) rt.synth.render(mono_.data(), len, segPos, tk.synth);
    else rt.drums.render(mono_.data(), len);
    float pk = localPk_[i];
    for (int k = 0; k < len; k++) {
      rt.gL += (rt.tL - rt.gL) * smoothCoef_;
      rt.gR += (rt.tR - rt.gR) * smoothCoef_;
      float l = mono_[size_t(k)] * rt.gL, r = mono_[size_t(k)] * rt.gR;
      ml[k] += l;
      mr[k] += r;
      pk = std::max(pk, std::max(std::fabs(l), std::fabs(r)));
    }
    localPk_[i] = pk;
  }
  if (click_.remain > 0) {
    for (int k = 0; k < len && click_.remain > 0; k++) {
      float env = float(click_.remain) / float(click_.total);
      float c = std::sin(click_.ph) * click_.amp * env * env;
      click_.ph += click_.inc;
      click_.remain--;
      ml[k] += c;
      mr[k] += c;
    }
  }
}

int Engine::renderChunk(float* out, int n) {
  const Snapshot* sp = acquire();
  if (!sp) {
    std::memset(out, 0, sizeof(float) * size_t(n) * 2);
    inUse_.store(nullptr);
    return n;
  }
  const Snapshot& s = *sp;
  size_t nt = std::min<size_t>(s.tracks.size(), kMaxTracks);

  bool play = playing_.load();
  if (wasPlaying_ && !play) allNotesOff(s);
  wasPlaying_ = play;
  Frame sk = seekReq_.exchange(-1);
  if (sk >= 0) { pos_.store(sk); allNotesOff(s); }
  Frame pos = pos_.load();

  bool loop = false;
  Frame loopStartF = 0, loopEndF = 0;
  if (play && loopOn_.load()) {
    loopStartF = s.tempo.ticksToFrames(loopStart_.load(), sr_);
    loopEndF = s.tempo.ticksToFrames(loopEnd_.load(), sr_);
    if (loopEndF > loopStartF && pos < loopEndF) { loop = true; n = int(std::min<Frame>(n, loopEndF - pos)); }
  }

  // track housekeeping and gain targets
  bool anySolo = false;
  for (size_t i = 0; i < nt; i++) anySolo = anySolo || s.tracks[i].solo;
  for (size_t i = 0; i < kMaxTracks; i++) {
    TrackRt& rt = *tr_[i];
    if (i >= nt) {
      if (rt.active) { rt.synth.reset(); rt.drums.reset(); rt.active = false; rt.init = false; }
      continue;
    }
    const Track& tk = s.tracks[i];
    if (rt.active && rt.kind != tk.kind) { rt.synth.reset(); rt.drums.reset(); }
    rt.kind = tk.kind;
    rt.active = true;
    bool audible = !tk.mute && (!anySolo || tk.solo);
    float v = audible ? tk.volume : 0.f;
    float p = std::min(std::max(tk.pan, -1.f), 1.f);
    float ang = (p + 1.f) * float(kPi) * 0.25f;
    rt.tL = v * std::cos(ang) * 1.41421356f;
    rt.tR = v * std::sin(ang) * 1.41421356f;
    if (!rt.init) { rt.gL = rt.tL; rt.gR = rt.tR; rt.init = true; }
    localPk_[i] = 0.f;
  }

  // events
  events_.clear();
  for (uint32_t t = tail_.load(std::memory_order_relaxed), h = head_.load(std::memory_order_acquire); t != h; t++) {
    const Live& l = ring_[t % ring_.size()];
    if (l.on) pushEv({0, 0, l.track, l.pitch, l.vel, -1, false});
    else pushEv({0, 2, l.track, l.pitch, 0.f, -1, false});
    tail_.store(t + 1, std::memory_order_release);
  }
  if (play) collect(s, pos, n);
  for (size_t i = 1; i < events_.size(); i++) {  // insertion sort by offset, stable
    Ev e = events_[i];
    size_t j = i;
    while (j > 0 && events_[j - 1].off > e.off) { events_[j] = events_[j - 1]; j--; }
    events_[j] = e;
  }

  std::fill(mixL_.begin(), mixL_.begin() + n, 0.f);
  std::fill(mixR_.begin(), mixR_.begin() + n, 0.f);
  int cur = 0;
  for (const Ev& e : events_) {
    if (e.off > cur) { segment(s, cur, e.off - cur, pos + cur); cur = e.off; }
    apply(s, e);
  }
  segment(s, cur, n - cur, pos + cur);

  // master
  if (!masterInit_) { masterG_ = s.masterGain; masterInit_ = true; }
  float mpk = 0.f;
  for (int k = 0; k < n; k++) {
    masterG_ += (s.masterGain - masterG_) * smoothCoef_;
    float l = softClip(mixL_[size_t(k)] * masterG_), r = softClip(mixR_[size_t(k)] * masterG_);
    out[size_t(k) * 2] = l;
    out[size_t(k) * 2 + 1] = r;
    mpk = std::max(mpk, std::max(std::fabs(l), std::fabs(r)));
  }
  masterPk_.store(std::max(mpk, masterPk_.load() * 0.9f));
  for (size_t i = 0; i < nt; i++) trackPk_[i].store(std::max(localPk_[i], trackPk_[i].load() * 0.9f));

  if (play) {
    pos += n;
    if (loop && pos >= loopEndF) { allNotesOff(s); pos = loopStartF; }
    pos_.store(pos);
  }
  inUse_.store(nullptr);
  return n;
}

}  // namespace hw
