#include "hw/project.h"
#include <algorithm>

namespace hw {
void MidiClip::sortNotes() {
  std::stable_sort(notes.begin(), notes.end(), [](const Note& a, const Note& b) { return a.start < b.start; });
}
}  // namespace hw
