#include <cstdio>
#include "hw/offline.h"
#include "hw/wav.h"
#include "song.h"

int main(int argc, char** argv) {
  const char* path = argc > 1 ? argv[1] : "demo.wav";
  hw::Snapshot s = hw::demoSong();
  auto pcm = hw::renderOffline(s, 44100, 18.0, 512);
  if (!hw::writeWav(path, pcm, 44100, 16)) { std::fprintf(stderr, "cannot write %s\n", path); return 1; }
  std::printf("wrote %s (%zu frames)\n", path, pcm.size() / 2);
  return 0;
}
