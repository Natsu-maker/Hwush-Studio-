#pragma once
#include "hw/project.h"

namespace hw {

inline void addNote(MidiClip& c, double beat, double lenBeats, int pitch, float vel) {
  Note n;
  n.start = Tick(beat * kPpq + 0.5);
  n.length = Tick(lenBeats * kPpq + 0.5);
  n.pitch = uint8_t(pitch);
  n.velocity = vel;
  c.notes.push_back(n);
}

/// A 120 bpm, 8 bar demo: drums, bass, pad and an arpeggio lead over Am F C G.
inline Snapshot demoSong() {
  Snapshot s;
  const int bars = 8;
  const Tick len = Tick(bars) * 4 * kPpq;

  Track drums; drums.name = "Drums"; drums.kind = InstrumentKind::Drums; drums.volume = 0.8f;
  Track bass; bass.name = "Bass"; bass.volume = 0.8f;
  bass.synth.osc1 = Wave::Saw; bass.synth.osc2 = Wave::Square; bass.synth.osc2Level = 0.3f; bass.synth.osc2Detune = 4;
  bass.synth.subLevel = 0.6f; bass.synth.cutoff = 500; bass.synth.resonance = 0.25f; bass.synth.filterEnvAmt = 1.5f;
  bass.synth.fltD = 0.15f; bass.synth.fltS = 0.2f; bass.synth.ampS = 0.8f; bass.synth.ampR = 0.08f; bass.synth.gain = 0.7f;
  Track pad; pad.name = "Pad"; pad.volume = 0.7f; pad.pan = -0.3f;
  pad.synth.osc2Detune = 12; pad.synth.osc2Level = 0.8f; pad.synth.cutoff = 1800; pad.synth.resonance = 0.15f;
  pad.synth.ampA = 0.35f; pad.synth.ampS = 0.9f; pad.synth.ampR = 1.0f; pad.synth.gain = 0.25f; pad.synth.voices = 12;
  Track lead; lead.name = "Lead"; lead.volume = 0.6f; lead.pan = 0.3f;
  lead.synth.osc1 = Wave::Square; lead.synth.osc2 = Wave::Saw; lead.synth.osc2Level = 0.4f; lead.synth.osc2Detune = 9;
  lead.synth.cutoff = 1500; lead.synth.resonance = 0.3f; lead.synth.filterEnvAmt = 2.5f; lead.synth.fltD = 0.25f; lead.synth.fltS = 0.1f;
  lead.synth.ampD = 0.25f; lead.synth.ampS = 0.15f; lead.synth.ampR = 0.2f; lead.synth.gain = 0.35f;

  MidiClip dc, bc, pc, lc;
  dc.length = bc.length = pc.length = lc.length = len;

  const int chordRoot[4] = {57, 53, 60, 55};                 // A, F, C, G (octave 3)
  const int chordThird[4] = {60, 57, 64, 59};
  const int chordFifth[4] = {64, 60, 67, 62};
  for (int bar = 0; bar < bars; bar++) {
    double b0 = bar * 4.0;
    for (int beat = 0; beat < 4; beat++) addNote(dc, b0 + beat, 0.25, 36, 1.0f);
    addNote(dc, b0 + 1, 0.25, 38, 0.95f);
    addNote(dc, b0 + 3, 0.25, 38, 0.95f);
    addNote(dc, b0 + 1, 0.25, 39, 0.5f);
    addNote(dc, b0 + 3, 0.25, 39, 0.5f);
    for (int e = 0; e < 8; e++) {
      double pos = b0 + e * 0.5;
      if (e == 7) addNote(dc, pos, 0.25, 46, 0.6f);
      else addNote(dc, pos, 0.25, 42, e % 2 ? 0.45f : 0.75f);
    }
    if (bar == bars - 1) {
      addNote(dc, b0 + 3.0, 0.25, 50, 0.9f); addNote(dc, b0 + 3.25, 0.25, 48, 0.9f);
      addNote(dc, b0 + 3.5, 0.25, 45, 0.9f); addNote(dc, b0 + 3.75, 0.25, 41, 0.9f);
    }
    int ch = (bar / 2) % 4;
    int root = chordRoot[ch] - 24;
    addNote(bc, b0 + 0.0, 0.75, root, 1.0f);
    addNote(bc, b0 + 1.5, 0.5, root, 0.8f);
    addNote(bc, b0 + 2.0, 0.75, root, 0.95f);
    addNote(bc, b0 + 3.5, 0.5, root + 12, 0.8f);
    if (bar >= 2) {
      const int tones[4] = {chordRoot[ch] + 12, chordThird[ch] + 12, chordFifth[ch] + 12, chordThird[ch] + 12};
      for (int e = 0; e < 8; e++) addNote(lc, b0 + e * 0.5, 0.4, tones[e % 4], 0.7f + 0.15f * float(e % 2 == 0));
    }
  }
  for (int ch = 0; ch < 4; ch++) {
    double b0 = ch * 8.0;
    addNote(pc, b0, 7.8, chordRoot[ch], 0.7f);
    addNote(pc, b0, 7.8, chordThird[ch], 0.7f);
    addNote(pc, b0, 7.8, chordFifth[ch], 0.7f);
  }
  for (MidiClip* c : {&dc, &bc, &pc, &lc}) c->sortNotes();
  drums.clips.push_back(dc); bass.clips.push_back(bc); pad.clips.push_back(pc); lead.clips.push_back(lc);
  s.tracks = {drums, bass, pad, lead};
  s.masterGain = 0.85f;
  return s;
}

}  // namespace hw
